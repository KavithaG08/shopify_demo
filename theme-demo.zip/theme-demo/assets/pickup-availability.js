customElements.get("product-availability-check") ||
  customElements.define(
    "product-availability-check",
    class extends HTMLElement {
      constructor() {
        super(),
          this.hasAttribute("in-stock") &&
            ((this.errorTemplate = this.querySelector(
              "template"
            ).content.firstElementChild.cloneNode(!0)),
            (this.handleClickRefresh = this.handleClickRefresh.bind(this)),
            this.retrieveAvailability(this.dataset.productId));
      }
      retrieveAvailability(productId) {
        if (!productId) return; 
        let baseUrl = this.dataset.baseUrl;
        baseUrl.endsWith("/") || (baseUrl += "/");
        const queryURL = `${baseUrl}variants/${productId}/?section_id=pickup-availability`;    
        fetch(queryURL)
          .then((response) => response.text())
          .then((htmlResponse) => {
            const parser = new DOMParser();
            const parsedDocument = parser.parseFromString(
              htmlResponse,
              "text/html"
            );
            const availabilitySection = parsedDocument.querySelector(".shopify-section");
            if (availabilitySection) {
              this.displayPreview(availabilitySection);
            } 
            else {
              this.showError();
            }
          })
          .catch((error) => {
           // console.error("Error fetching availability:", error);
            this.showError();
          });
      }

      handleClickRefresh() {
        this.retrieveAvailability(this.dataset.productId);
      }
      refreshProduct(variant) {
        if (variant && variant.available) {
          this.retrieveAvailability(variant.id);
        } else {
          this.removeAttribute("in-stock");
          this.innerHTML = "";
        }
      }
      showError() {
        this.innerHTML = ""
        // (this.innerHTML = ""),
        //   this.appendChild(this.errorTemplate),
        //   this.querySelector("button").addEventListener(
        //     "click",
        //     this.handleClickRefresh
        //   );
      }
      displayPreview(e) {
        const offcanvas = document.querySelector("#pickupDrawer");
        if (offcanvas) {
          const newDetails = e.querySelector("product-availability-details").innerHTML;
          if(newDetails){offcanvas.innerHTML = newDetails;}          
        } else {
          const details = e.querySelector("product-availability-details");
          if (details) {
            document.body.appendChild(details);
          }
        }
        const preview = e.querySelector("product-availability-preview");
        if (preview) {
          this.innerHTML = preview.outerHTML;
        }
      }
    }
  );
