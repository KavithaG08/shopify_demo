document.addEventListener("DOMContentLoaded", function () {
  if (document.querySelector("#AjaxinatePagination")) {    
   endlessScroll = new Ajaxinate();
    }
  
  const fetchProducts = async () => {
    const oldProducts = document.querySelector('.all-products');
    if (!oldProducts) {
        console.error("No products container found.");
        return;
    }

    const productGridContainer = oldProducts.querySelector('.product-grid-container');
    if (!productGridContainer) {
        console.error("No product grid container found.");
        return;
    }

    const filters = document.querySelector('product-filters');
    const offcanvasElement = document.getElementById('filtersOffcanvas');
    
    

    // Add loading class
    productGridContainer.classList.add("loading");
    setTimeout(() => {
        productGridContainer.classList.remove("loading");
    }, 1000);

    try {
        // Fetch the updated product data
        const response = await fetch(window.location.href);
        const data = await response.text();
        const parser = new DOMParser();
        const newProducts = parser.parseFromString(data, 'text/html');       
        const drawerLayout = newProducts.querySelector('.filter_layout-drawer')
        const filtersOffcanvas = drawerLayout?.closest('.filtersOffcanvas') || newProducts.querySelector('.filter_layout-drawer');
   
          if (filtersOffcanvas) {
            const offcanvasInstance = bootstrap.Offcanvas.getOrCreateInstance(filtersOffcanvas);
            offcanvasInstance.show();
          }

        // Replace the old products and filters
        oldProducts?.replaceWith(newProducts.querySelector('.all-products'));
        filters?.replaceWith(newProducts.querySelector('product-filters'));

        // Reinitialize functionalities
        initializePriceRangeSlider();
        setupFilterRemoval();
        customSortSelect();
        initQuickModal();
        if (endlessScroll && typeof endlessScroll.destroy === 'function') {
            endlessScroll.destroy();
        }
        initEndlessScroll();
      
        // Handle the "filtersOffcanvas" instance
        if (offcanvasElement) {
            const offcanvasInstance = bootstrap.Offcanvas.getInstance(offcanvasElement);
            if (offcanvasInstance) {
                offcanvasInstance._config.backdrop = true;
               offcanvasInstance.hide();  
               
            }
        }
  
    } catch (error) {
        console.error("Failed to fetch and update products:", error);
    }

   
};


  function setupFilterRemoval() {   
  document.querySelectorAll('#selected-filters .btn-close').forEach(btn => {
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      const hrefUrl = btn.getAttribute('href');
      window.history.replaceState({}, '', hrefUrl);
      fetchProducts(hrefUrl);
    });
  });
}


  class sidebarFilters extends HTMLElement {
    constructor() {
      super();
      this.form = this.querySelector('form');
      this.form.querySelectorAll('input').forEach(input => {
        input.addEventListener('change', () => {                      
          const params = new URLSearchParams(new FormData(this.form));         
          const url = `${window.location.pathname}?${params.toString()}`;          
          window.history.replaceState({}, '', url);         
         fetchProducts();
        });
      });

      document.querySelectorAll('.clear-all-filters').forEach(clearBtn => {
        const params = new URLSearchParams(window.location.search);
        for (const key of params.keys()) {
          if (key.includes('filter.')) {
            clearBtn.removeAttribute('hidden');
          }
        }

        clearBtn.addEventListener('click', () => {
          for (const key of [...params.keys()]) {
            if (key.includes('filter.')) {
              params.delete(key);
            }
          }

          const url = `${window.location.pathname}?${params.toString()}`;
          window.history.replaceState({}, '', url);
          fetchProducts();
        });
      });
    }
  }

  customElements.define('product-filters', sidebarFilters);

  class productSorting extends HTMLElement {
    constructor() {
      super();
      this.querySelectorAll('input').forEach(input => {
        input.addEventListener('change', () => {
          this.updateURL(input.value);
          fetchProducts();
        });
      });
    }

    updateURL(value) {
      const params = new URLSearchParams(window.location.search);
      params.set('sort_by', value);
      params.delete('page');
      const url = `${window.location.pathname}?${params.toString()}`;
      window.history.replaceState({}, '', url);
    }
  }

  customElements.define('product-sorting', productSorting);

  class productPagination extends HTMLElement {
    constructor() {
      super();

      this.querySelectorAll('.page-link').forEach(anchor => {
        anchor.addEventListener('click', (event) => {
          event.preventDefault();
          this.updateURL(anchor.dataset.linkTarget);
          fetchProducts();
        });
      });
    }

    updateURL(value) {
      const params = new URLSearchParams(window.location.search);
      params.set('page', value);
      const url = `${window.location.pathname}?${params.toString()}`;
      window.history.replaceState({}, '', url);
    }
  }
   customElements.define('product-pagination', productPagination);


// Helper function to initialize the price range slider
  function initializePriceRangeSlider() {
   const $rangeSlider = $(".js-range-slider"),
  $priceStart = $(".field__input_min"),
  $priceEnd = $(".field__input_max"),
  priceMin = parseFloat($rangeSlider.data("min")),
  priceMax = parseFloat($rangeSlider.data("max")),
  fromValue = $priceStart.val() ? $priceStart.val() : priceMin,
  toValue = $priceEnd.val() ? $priceEnd.val() : priceMax;
    $dataKey = $('#main-search-filters').data('price-key');

$rangeSlider.ionRangeSlider({
  skin: "round",
  type: "double",
  min: priceMin,
  max: priceMax,
  from: fromValue,
  to: toValue,
  onChange: updateInputs, // Update inputs on slider change
  onFinish: () => {
    sendAjaxRequest(); // Trigger AJAX request on finish
    updateInputs($rangeSlider.data("ionRangeSlider").result); // Ensure inputs reflect slider values
  }
});

const sliderInstance = $rangeSlider.data("ionRangeSlider");

// Update the input fields when the slider changes
function updateInputs(data) {
  const from = data.from;
  const to = data.to;
  $priceStart.val(from);
  $priceEnd.val(to);
}

function sendAjaxRequest() {
  const from = $priceStart.val();
  const to = $priceEnd.val();

  let params = new URLSearchParams(window.location.search);
  params.set("price_min", from);
  params.set("price_max", to);
  if($dataKey){
    var queryString = $dataKey+`filter.v.price.gte=${from}&filter.v.price.lte=${to}`; 
    }else {
    var queryString = `filter.v.price.gte=${from}&filter.v.price.lte=${to}`;  
    }
  //const url = `${window.location.pathname}?${params.toString()}`;
  var url = `${window.location.pathname}?${queryString}`;
  window.history.replaceState({}, '', url);

  fetchProducts(); // Load new products based on price range
  updateInputs(sliderInstance.result); // Reflect the current slider values in input fields
}

// Update the range slider and trigger AJAX on input field changes
$priceStart.on("change", function () {
  let val = parseFloat($(this).val());
  if (val < priceMin) val = priceMin;
  if (val > sliderInstance.result.to) val = sliderInstance.result.to;
  sliderInstance.update({ from: val });
  sendAjaxRequest();
});

$priceEnd.on("change", function () {
  let val = parseFloat($(this).val());
  if (val < sliderInstance.result.from) val = sliderInstance.result.from;
  if (val > priceMax) val = priceMax;
  sliderInstance.update({ to: val });
  sendAjaxRequest();
});
  }

  // Initialize the price range slider on page load
  initializePriceRangeSlider();
  setupFilterRemoval();
  customSortSelect();
  initQuickModal();
  if (endlessScroll && typeof endlessScroll.destroy === 'function') {
        endlessScroll.destroy();
    }
  initEndlessScroll();
});


function customSortSelect() {
const customList = document.querySelector('.custom-select-list');
if (!customList) return;
const listItems = customList.querySelectorAll('li');
const button = document.querySelector('.custom-select-button');

function updateButtonText(text) {
  button.textContent = text;
}

listItems.forEach(item => {
  item.addEventListener('click', function() { 
    const selectedText = this.textContent.trim();
    updateButtonText(selectedText);  
  });
});
} 


if (document.querySelector("#AjaxinatePagination")) {    
function initEndlessScroll() {
 let AjaxMethod = document.querySelector(".pagination-method-loadmore") ? "click" : "scroll";
    endlessScroll = new Ajaxinate({
        container: '#AjaxinateContainer',
        pagination: '#AjaxinatePagination',
        method: AjaxMethod,
        offset: 0,
        callback: initQuickModal,
    });
}  
};

