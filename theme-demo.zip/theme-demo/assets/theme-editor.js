window.addEventListener("load", () => {
  
  document.addEventListener("shopify:section:load", function (event) {
    const section = event.target;

     if (section.classList.contains("section-featured-collection")) {
      window.dispatchEvent(new Event("resize"));
      new WDT_Swiper(); 
    }
     if (section.classList.contains("section-testimonials")) {
      window.dispatchEvent(new Event("resize"));
      new WDT_Testimonial(); 
    }

     if (section.classList.contains("section-shop-the-look")) {
      window.dispatchEvent(new Event("resize"));
      new ShopLookSection(); 
    }
    

    if (section.classList.contains("main-product-template")) {
      window.dispatchEvent(new Event("resize"));
      if (typeof ProductGallery !== "undefined") {
        new ProductGallery(section);  
      } else {
        console.error("ProductGallery class is not defined");
      }
    }

    if (section.classList.contains("slideshow")) {
      window.dispatchEvent(new Event("resize"));
      new WDT_slideShow();  
    }

    if (section.classList.contains("section-marquee")) {
      window.dispatchEvent(new Event("resize"));
    }

    if (section.classList.contains("text-with-icons")) {
      initWdtIcon();
    }
 if (section.classList.contains("section-newsletter-popup")) {
     initNewsletterModal();
 }

    if (section.classList.contains("wdt-related-products")) {
      new ProductRecommendations();  
 }
 if (section.classList.contains("collection-gallery")) {
      new WDT_collectionGallery();  
 }
    

       if (section.querySelector("#sticky-atc-bar")) {
      initializeStickyAtcBar();
    }
    
  });

  document.addEventListener("shopify:block:select", function (event) {
    const block = event.target;
    if (block.classList.contains("slide-item")) {
      new WDT_Slider();  
    }
  });

  function initWdtIcon() {
    let wdtIconItem = document.querySelectorAll(".text-with-icon-item");
    if (wdtIconItem) {
      wdtIconItem.forEach((wdtItem) => {
        let wdtItem_height = wdtItem.clientHeight / 2;
        let wdtItem_parent = wdtItem.closest(".section-text-with-icon");
        if (wdtItem_parent) {
          wdtItem_parent.setAttribute(
            "style",
            `--before-top: ${wdtItem_height}px;`
          );
        }
      });
    }
  }
  initWdtIcon();
});
