
if (!customElements.get('add-to-cart-form')) {
  customElements.define('add-to-cart-form',
    class AddToCartForm extends HTMLElement {
       constructor() {
          super();
          this.form = this.querySelector('form');         
         if(!this.form) return;         
          const selectElement = this.form.querySelector('[name=id]');         
         // const variantSelect = this.form.querySelector('select[name="id"]');
          const variantId = selectElement ? selectElement.value : selectElement.value;        
          this.submitButton = this.querySelector('[type="button"]');                       
         this.submitButton.addEventListener('click', this.handleAddToCart.bind(this));           
        }

        // Handle Add to Cart event
        handleAddToCart(event) {  
          event.preventDefault();
          const formData = new FormData(this.form);
          const variantId = this.form.querySelector('[name=id]').value;
          formData.append('id', variantId);
          formData.append('quantity', '1'); 
          fetch('/cart/add.js', {
            method: 'POST',
            body: formData,
            headers: {
              'Accept': 'application/json',
            },
          })
          .then(response => response.json())
          .then(data => {
           // console.log('Product added to cart:', data);
            showCartDrawer();
            fetchCart(); 
          })
          .catch(error => {
            console.error('Error adding product to cart:', error);
          });
        }        
    }
  );
}

      // Cart handling functions
      // function showCartDrawer() {
      //   var offcanvasElement = document.getElementById('cartOffCanvas');
      //   if(!offcanvasElement) return;
      //   var bsOffcanvas = new bootstrap.Offcanvas(offcanvasElement);
      //   bsOffcanvas.show();
      // }


      function showCartDrawer() {
    const cartDrawerElement = document.getElementById('cartOffCanvas');
    if (cartDrawerElement) {
        const cartDrawer = new bootstrap.Offcanvas(cartDrawerElement);
        cartDrawer.show();

        // Clean up lingering modals
        const backdrop = document.querySelector('.offcanvas-backdrop');
        if (backdrop) {
            backdrop.parentNode.removeChild(backdrop);
        }
    }
}




      function fetchCart(data) {
     fetch('/cart.js')
    .then(response => response.json())
    .then(cart => {     
      const mainDrawer = document.querySelector('.cartDrawer'); 
      const cartItemsList = document.getElementById('cart-items-list');
      const totalElement = document.getElementById('cartSubTotal');
      const lineItemDiscountDataElement = document.getElementById("line-item-discounts-data");  
      const totalDiscountData = document.getElementById("cart-discounts-data");  
      const collectionsInfo = document.getElementById('cart-message');
      const cartFooter = document.getElementById('cartFooter');
      
      // Clear the cart items list
      cartItemsList.innerHTML = '';
      let total = 0;

      // Update cart item count
      updateCartCount(cart.item_count);

      // Handle empty cart
      if (cart.items.length === 0) {
        mainDrawer.classList.add('drawer-empty');
        collectionsInfo.style.display = "block";
        cartFooter.querySelector('.cart__checkout-button').disabled = true;
        if (totalElement) {
          totalElement.classList.add('invisible');
        }
      } else {
        mainDrawer.classList.remove('drawer-empty');
        collectionsInfo.style.display = "none";
        if (totalElement) {
          totalElement.classList.remove('invisible');
        }
        cartFooter.querySelector('.cart__checkout-button').disabled = false;

        // Loop through cart items and add them to the list
        cart.items.forEach(item => {
          total += item.line_price;

          let cartItemHTML = `
  <div class="cart-item p-3" id="CartItem-${item.key}" data-line-item-key="${item.key}">
    <div class="card flex-row gap-3 flex-sm-nowrap align-items-center">                   
      <div class="cart-img cart-item__image-container">
        <a href="${item.url}" class="cart-item__link">          
          <img src="${item.image}" class="cart-item__image border border-2" alt="${item.title}" width="150" height="150">
        </a>
      </div>
      <div class="card-body p-0">
        <h5 class="mb-2 h6">
          <a href="/products/${item.handle}?variant=${item.variant_id}" class="cart_item_name break text-decoration-none">${item.handle}</a>
        </h5>        
        <div class="product-option mb-2 invisible d-none">${(item.price / 100).toFixed(2)}</div>
        <div class="mb-3 d-none">
          ${item.options_with_values.map(option => `
            <div>${option.name}: ${option.value}</div>
          `).join('')}
        </div>
         <span class="subscription_minicart">
            ${item.selling_plan_allocation ? item.selling_plan_allocation.selling_plan.name : ''}
        </span>
        <div class="d-flex flex-wrap gap-3 row-gap-0 justify-content-between">
        <div class="details">
            <div class="cart-item__totals d-flex gap-2">
            <span class="d-flex gap-2">${item.line_level_discount_allocations.length > 0 ? `
              <div class="discount-exists opacity-50">
                <del>${Shopify.formatMoney(item.original_line_price, wdtTheme.moneyFormat)}</del>                        
              </div>
              ` :''}
            <div>${Shopify.formatMoney(item.line_price, wdtTheme.moneyFormat)}</div></span>
            <!-- Unit Price Logic -->
            ${item.unit_price_measurement ? `
              <div class="unit-price caption text-muted mb-2">
                <span class="visually-hidden">Unit price</span>
                <span class="fw-bold">${Shopify.formatMoney(item.unit_price, wdtTheme.moneyFormat)}</span>
                <span aria-hidden="true">/</span>
                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                ${item.unit_price_measurement.reference_value != 1 ? `
                  <span>${item.unit_price_measurement.reference_value}</span>
                ` : ''}
                <span>${item.unit_price_measurement.reference_unit}</span>
              </div>
            ` : ''}
          </div>
          ${item.line_level_discount_allocations.length > 0 ? `
            <div class="discount-exists">                       
              ${item.line_level_discount_allocations.map(discount => `
                <div class="discount-text">
                  <svg class="icon icon-discount" viewBox="0 0 12 12"><path fill="currentColor" fill-rule="evenodd" d="M7 0h3a2 2 0 0 1 2 2v3a1 1 0 0 1-.3.7l-6 6a1 1 0 0 1-1.4 0l-4-4a1 1 0 0 1 0-1.4l6-6A1 1 0 0 1 7 0m2 2a1 1 0 1 0 2 0 1 1 0 0 0-2 0" clip-rule="evenodd"/></svg>
                  ${discount.discount_application.title}
                </div>
              `).join('')}
            </div>
          ` : ''}

          <div class="cart-item__quantity d-flex align-items-center rounded-1 border border-2">
            <button class="btn btn-lg border-0 px-2 py-1 shadow-none" aria-label="decrement">  
              <span class="quantity__button decrement-item d-flex align-items-center justify-content-center"  data-line="${item.key}" data-quantity="${item.quantity - 1}"><svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" width="16" height="16" fill="currentColor" class="icon-minus" viewBox="0 0 16 16">
              <path d="M4 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 4 8"/>
              </svg></span></button>
            <span class="w-100 bg-body text-center border-0">${item.quantity}</span>
            <button class="btn btn-lg border-0 px-2 py-1 shadow-none" aria-label="increment">
            <span class="quantity__button increment-item d-flex align-items-center justify-content-center" data-line="${item.key}" data-quantity="${item.quantity + 1}"><svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" width="16" height="16" fill="currentColor" class="icon icon-plus" viewBox="0 0 16 16">
            <path  d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
            </svg></span></button>
          </div>
          
        </div>
        <div class="align-self-end">
          <button class="remove bg-body border-0"><span class="cart-remove-button" data-line="${item.key}">Remove</span></button>
        </div>
        
        </div>

        <div class="drawer-cart-message d-none"></div>
      </div>
    </div>
  </div>
`;
          cartItemsList.innerHTML += cartItemHTML;
        });

        // Update total element
        if (totalElement) {
          totalElement.textContent = wdtTheme.sub_total + " :  " + Shopify.formatMoney(total, wdtTheme.moneyFormat);
        }

        // Cart-level discounts
        if (cart.cart_level_discount_applications.length > 0) {
          let cartLevelDiscountHTML = `
            <div class="cart-level-discount mt-4">          
              <ul class="cart-level-discount-list list-unstyled p-0">
                ${cart.cart_level_discount_applications.map(discount => `
                  <li>
                    <strong>${discount.title}</strong>: ${Shopify.formatMoney(discount.total_allocated_amount, wdtTheme.moneyFormat)}
                  </li>
                `).join('')}
              </ul>
            </div>
          `;
          if (totalDiscountData) {
            totalDiscountData.innerHTML = cartLevelDiscountHTML;
          }
        }
      }
    })
    .catch(error => console.error('Error fetching cart:', error));
}



function updateCartCount(count) {
  const cartCountElement = document.getElementById('header-cart-count');
if(!cartCountElement) return;  
  if (count === 0) {    
    cartCountElement.innerHTML = `      
      <span class="visually-hidden">0</span>
    `;
    cartCountElement.classList.add('invisible');
  } else {    
    cartCountElement.innerHTML = `      
      <span class="visually-hidden">items in your cart</span>      
        <span aria-hidden="true">${count}</span>
        <span class="visually-hidden">${count} items in your cart</span>      
    `;
    cartCountElement.classList.remove('invisible');
  }
}

function updateQuantity(line, quantity) {  
  const lineElement = document.getElementById(`CartItem-${line}`);  
  const messageContainer = lineElement.querySelector('.drawer-cart-message');
  
  fetch('/cart/change.js', {
    method: 'POST',
    headers: { 
      'Content-Type': 'application/json',
      'X-Requested-With': 'XMLHttpRequest' 
    },
    body: JSON.stringify({ id: line, quantity: quantity })
  }) 
 .then(response => {
  if (!response.ok) {
    return response.json().then(errorData => {      
      throw new Error(errorData.message || 'An unexpected error occurred.');
    });
  }
  return response.json(); 
})
.then((data) => {  
  fetchCart(); 
  if (data.status === 'error') {    
    messageContainer.classList.remove('d-none');
    messageContainer.innerHTML = `<span class='pro_error d-flex mt-1'>Error: ${data.message}</span>`;
  }
})
.catch(error => {  
  if (!messageContainer) {    
    console.error('Message container not found');
    return;
  }
  messageContainer.classList.remove('d-none'); 
  messageContainer.innerHTML = `<span class='pro_error'>Error: ${error.message || 'An unexpected error occurred.'}</span>`;
});

}


  function removeItem(line) {
        updateQuantity(line, 0);
      }

      document.addEventListener('click', function (event) {
        if (event.target.matches('.increment-item')) {
          const line = event.target.getAttribute('data-line');
          const newQuantity = parseInt(event.target.getAttribute('data-quantity'));
          if (line) updateQuantity(line, newQuantity);
        }

        if (event.target.matches('.decrement-item')) {
          const line = event.target.getAttribute('data-line');
          const newQuantity = parseInt(event.target.getAttribute('data-quantity'));
          if (line && newQuantity >= 0) updateQuantity(line, newQuantity);
        }

        if (event.target.matches('.cart-remove-button')) {
          const line = event.target.getAttribute('data-line');
          removeItem(line);
        }
      });

      // Fetch cart when the cart drawer is opened
      const offcanvasElement = document.getElementById('cartOffCanvas');
      offcanvasElement.addEventListener('shown.bs.offcanvas', () => {
        fetchCart();  
      });

      // Optionally, you can also fetch the cart on page load to preload the items
      window.addEventListener('load', () => {
        fetchCart();
      });
      let checkoutBtn = document.getElementById('checkout-button');
      let checkAction = checkoutBtn.querySelector('span')
      if(checkAction){
      checkAction.addEventListener('click', function () {
      window.location.href = '/checkout';
      });
      }


// MAIN PRODUCT
if (!customElements.get('main-product-form')) {
  customElements.define(
    'main-product-form',
    class ProductForm extends HTMLElement {
      constructor() {
        super();
        this.form = this.querySelector('form');              
        this.form.addEventListener('submit', this.onSubmitHandler.bind(this));
        this.submitButton = this.querySelector('[type="submit"]'); 
        this.productContainer = this.closest('.product--information');
        // Track quick view modal state
       // this.quickViewOffcanvas = document.getElementById('quickViewOffcanvas')? new bootstrap.Offcanvas(document.getElementById('quickViewOffcanvas')): null;
        if (typeof bootstrap !== 'undefined') {
        this.quickViewOffcanvas = new bootstrap.Offcanvas(document.getElementById('quickViewOffcanvas'));
        } 
      }
 
    onSubmitHandler(evt) {
    evt.preventDefault();
    const variantId = this.form.querySelector('[name=id]').value;
    const quantityInput = this.productContainer.querySelector('input[name="quantity"]');
    const quantity = parseInt(quantityInput ? quantityInput.value : '1', 10);
    this.form.querySelector('.text-danger').classList.remove('invisible');

       const qtyStatusElement = this.form.querySelector('.text-danger');
      if (qtyStatusElement) {  
        qtyStatusElement.classList.remove('invisible');
      }
      
    if (quantity === 0) {
        const errorSpan = this.form.querySelector('.text-danger');
        if (errorSpan) {
            errorSpan.textContent = window.cartStrings.quantity_correct;
        } else {
            alert(window.cartStrings.quantity_correct);
        }
        return;
    }

    const minValue = quantityInput.min;
    const maxValue = quantityInput.max;
    const min = parseInt(minValue, 10);
    const max = parseInt(maxValue, 10);
    let updatedQuantity;

    const errorQuantity = window.cartStrings.quantityError.replace('[quantity]', max);
    const errorSpan = this.form.querySelector('.text-danger');

    if (quantity > max) {
        if (errorSpan) errorSpan.textContent = errorQuantity;
        return;
    } else {
        updatedQuantity = quantity;
        errorSpan.textContent = " ";
    }

    // Fetch the cart to check for existing variants
    fetch('/cart.js')
        .then(response => response.json())
        .then(cart => {
            const existingItem = cart.items.find(item => item.variant_id == variantId);

            if (existingItem) {
                const totalQuantity = existingItem.quantity + updatedQuantity;
              //  console.log("totalQuantity"+totalQuantity);
                if (totalQuantity > max) {
                  //  alert(`Only ${max - existingItem.quantity} items remaining in stock for this variant.`);
                  const remainQty = `${max - existingItem.quantity}`;
                  errorSpan.textContent = window.cartStrings.quantityRemain.replace('[quantity]', remainQty);
                  errorSpan.classList.remove('d-none');
                    return; // Prevent adding to the cart
                }
              else{
                errorSpan.classList.add('d-none');
              }
            }
            this.addToCart(variantId, updatedQuantity);
        })
        .catch(error => console.error('Error fetching cart:', error));
}

addToCart(variantId, quantity) {
    const formData = new FormData(this.form);

    formData.append('id', variantId);
    formData.append('quantity', quantity);

    // Collect custom properties for gift cards, if present
    const recipientForm = document.querySelector('.receipient__form');
    if (recipientForm && recipientForm.getAttribute('aria-expanded') === 'true') {
        const recipientEmail = this.form.querySelector('[name="properties[Recipient email]"]').value;
        if (!recipientEmail) {
            const emailErrorMessage = document.getElementById('email-error-message');
            emailErrorMessage.textContent = 'Email field cannot be empty. Please provide a valid email address.';
            emailErrorMessage.classList.add('alert', 'alert-danger');
            return;
        }
    }

    // Append gift card custom properties to formData
    ['Recipient Name', 'Recipient email', 'Message', 'Send on', '__shopify_send_gift_card_to_recipient'].forEach(prop => {
        const value = this.form.querySelector(`[name="properties[${prop}]"]`)?.value || '';
        formData.append(`properties[${prop}]`, value);
    });

    fetch('/cart/add.js', {
        method: 'POST',
        body: formData,
        headers: { 'Accept': 'application/json' },
    })
        .then(response => {
            if (!response.ok) {
                return response.json().then(error => { throw new Error(error.message); });
            }
            return response.json();
        })
        .then(data => {
            fetchCart(); // Update the cart
            showCartDrawer(); // Open the cart drawer
           
          if (this.quickViewOffcanvas && isQuickViewOpen) {          
          const quickOffcanvasElement = document.getElementById('quickViewOffcanvas');
            if (quickOffcanvasElement) {
            quickOffcanvasElement.classList.remove('show');
            document.body.classList.remove('offcanvas-open');      
            const hiddenEvent = new Event('hidden.bs.offcanvas');
            quickOffcanvasElement.dispatchEvent(hiddenEvent);
            }
      }

        })
        .catch(error => {
            console.error('Error adding product to cart:', error);
            if (error.message.includes("Email can't be blank")) {
                const emailErrorMessage = document.getElementById('email-error-message');
                emailErrorMessage.textContent = 'Email is required. Please provide a valid email address.';
                emailErrorMessage.classList.add('alert', 'alert-danger');
            } else {
                alert(error.message);
            }
        });
}

    }
  );
}



