if (!customElements.get('wdt-slideshow')) {
  customElements.define('wdt-slideshow', class WDT_slideShow  extends HTMLElement {
    constructor() {
        super();
        this.slider = this.querySelector("[data-swiper-slider]");
    }

    connectedCallback() {
        this.init();
    }

    init() {
        if (!this.slider) {            
          console.warn("Slider element not found");
            return;
        }

        const slideItems = this.slider.querySelectorAll(".slide-item");
        if (slideItems.length <= 1) {
            console.warn("Insufficient slides to initialize Swiper");
            return;
        }

        const sliderOptions = this.slider.getAttribute("data-slider-options");

        if (!sliderOptions) {
            console.warn("Slider options not found or invalid");
            return;
        }

        try {
            const options = JSON.parse(sliderOptions);

            Object.keys(options).forEach(key => {
                if (typeof options[key] === "string" && /^\d+$/.test(options[key])) {
                    options[key] = parseInt(options[key], 10);
                }
            });

            const autoplay = options.auto_play > 0 ? options.auto_play * 1000 : false;
            const loop = options.loop === "true" || options.loop === true;           
            const fade = options.fade === "true" || options.fade === true;

            const swiperOptions = {
                loop: loop,
                autoplay: autoplay ? { delay: autoplay, disableOnInteraction: false,  pauseOnMouseEnter: true } : false,
                effect: fade ? 'fade' : 'slide',
                fadeEffect: { crossFade: true },
                speed: 2000,
                  pagination: {
                  el: this.querySelector(".swiper-pagination"),
                clickable: true
            },
                navigation: {
                    nextEl: this.querySelector(".swiper-button-next"),
                    prevEl: this.querySelector(".swiper-button-prev")
                },
                lazy: {
                    loadOnTransitionStart: true,
                    loadPrevNext: true
                },
                slidesPerView: 1,
                ...options.options
            };

           // console.log("Initializing Swiper with options:", swiperOptions);
            this.swiperInstance = new Swiper(this.slider, swiperOptions);

        } catch (error) {
            console.error("Error parsing slider options:", error);
        }
    }
});
}


if (!customElements.get('text-with-icons-slider')) {
  customElements.define('text-with-icons-slider', class textWidthIcons_Slider  extends HTMLElement {

    constructor() {
        super();      
        this.sliderConfigElement = this.querySelector("[data-slider-options]");        
        if(this.sliderConfigElement)this.initializeSlider();
    }

    initializeSlider() {        
        const sliderOptionsData = this.sliderConfigElement.getAttribute("data-slider-options");
        if (sliderOptionsData === null || sliderOptionsData === "") return null;
        const sliderOptions = $.extend(true, {
            effect: "slide",
            direction: "horizontal",
            autoplay: true,
            autoplaySpeed: 5,
            spaceBetweenSlides: 0,            
            additionalOptions: {}
        }, JSON.parse(sliderOptionsData));
        
        const numericPattern = /^\d+$/;
        Object.keys(sliderOptions).forEach((key) => {
            if (typeof sliderOptions[key] === "string" && numericPattern.test(sliderOptions[key])) {
                sliderOptions[key] = parseInt(sliderOptions[key], 10);
            }
        });

        let autoplaySettings = false;
        if (sliderOptions.auto_play > 0) {
            autoplaySettings = { delay: 1000 * sliderOptions.auto_play };
        }
        let loopEnabled = false;
        if (sliderOptions.loop === "true" || sliderOptions.loop === true || sliderOptions.loop === 1) {
            loopEnabled = true;
        }

        let centeredSlides = false;
        if (sliderOptions.mode === "true" || sliderOptions.mode === true ) {
            centeredSlides = true;
        }

        const swiperOptions = $.extend(true, {
            init: false,
            spaceBetween: sliderOptions.space,
            loop: loopEnabled,
            preventClicks: true,
            preventClicksPropagation: true,
            autoplay: autoplaySettings,
            centeredSlides: centeredSlides,
            navigation: {
                nextEl: this.sliderConfigElement.querySelector(".swiper-button-next"),
                prevEl: this.sliderConfigElement.querySelector(".swiper-button-prev")
            },
            pagination: {
                el: this.sliderConfigElement.querySelector(".swiper-pagination"),
                clickable: true
            },
            lazyLoading: true,
            focusableElements: 'input, select, option, textarea, video, label',
           speed: 2000,
            breakpoints: {
                320: {
                    slidesPerView: sliderOptions.mobile,               
                    slidesPerColumn: 1
                },
                768: {
                    slidesPerView: sliderOptions.tablet,
                    slidesPerColumn: 1,
                    spaceBetween: sliderOptions.space * 0.7
                },
                992: {
                    slidesPerView: sliderOptions.laptop,
                    slidesPerColumn: 1,
                    spaceBetween: sliderOptions.space * 0.8
                },
                1400: {
                    slidesPerView: sliderOptions.desktop,
                    slidesPerColumn: 1
                }
            }
        }, sliderOptions.additionalOptions);

        const swiperContainer = this.sliderConfigElement.querySelector("[data-swiper-slider]");
        const swiperInstance = new Swiper(swiperContainer, swiperOptions);

        swiperInstance.on("init", () => {
            swiperInstance.update();
        });

        swiperInstance.init();
    }
});
}


if (!customElements.get('wdt-collection-slider')) {
  customElements.define('wdt-collection-slider', class WDT_Collection extends HTMLElement {
    constructor() {
      super();
      this.slider = this.querySelector("[data-swiper-slider]");
      if (!this.slider) {
        console.error('Swiper slider element not found.');
        return;
      }
      this.init();
    }

    init() {
      const sliderOptionsData = this.slider.parentElement?.getAttribute("data-slider-options");
      if (!sliderOptionsData) {
        console.error('Slider options not found.');
        return;
      }

      let options;
      try {
        options = JSON.parse(sliderOptionsData);
      } catch (error) {
        console.error('Error parsing slider options:', error);
        return;
      }

      // Convert numeric string values to integers
      Object.keys(options).forEach(key => {
        if (typeof options[key] === "string" && /^\d+$/.test(options[key])) {
          options[key] = parseInt(options[key], 10);
        }
      });

      const autoplay = options.auto_play > 0 ? { delay: options.auto_play * 1000 } : false;
      const loop = options.loop === "true" || options.loop === true;
      const centeredSlides = options.mode === "true" || options.mode === true;

      const swiperOptions = {
        loop: loop,
        autoplay: autoplay,
        centeredSlides: centeredSlides,
        speed: options.speed || 2000,
        pagination: {
          el: this.slider.parentElement?.querySelector(".swiper-pagination"),
          clickable: true,
        },
        navigation: {
          nextEl: this.slider.parentElement?.querySelector(".swiper-button-next"),
          prevEl: this.slider.parentElement?.querySelector(".swiper-button-prev"),
        },
        lazy: {
          loadOnTransitionStart: true,
          loadPrevNext: true,
        },
        slidesPerView: options.desktop || 4,
        spaceBetween: options.space || 0,
        breakpoints: {
          320: {
            slidesPerView: options.mobile || 1,
            spaceBetween: (options.space || 0) * 0.7,
          },
          576: {
            slidesPerView: options.tablet || 2,
            spaceBetween: (options.space || 0) * 0.7,
          },
          992: {
            slidesPerView: options.laptop || 3,
            spaceBetween: (options.space || 0) * 0.7,
          },
          1200: {
            slidesPerView: options.desktop || 4,
          },
        },
      };

      this.swiperInstance = new Swiper(this.slider, swiperOptions);
    }
  });
}


if (!customElements.get('wdt-swiper-slider')) {
  customElements.define('wdt-swiper-slider', class WDT_Swiper  extends HTMLElement{
    constructor() {
        super();     
        this.sliderConfigElement = this.querySelector("[data-slider-options]");         
        if (this.sliderConfigElement) this.initializeSlider();
    }

    initializeSlider() {       
        const sliderOptionsData = this.sliderConfigElement.getAttribute("data-slider-options");      
        if (!sliderOptionsData) return;
        const sliderOptions = $.extend(true, {
            effect: "slide",
            direction: "horizontal",
            autoplay: true,
            autoplaySpeed: 5,
            spaceBetween: 0, 
            additionalOptions: {}
        }, JSON.parse(sliderOptionsData));
       
        const numericPattern = /^\d+$/;
        Object.keys(sliderOptions).forEach((key) => {        
            if (typeof sliderOptions[key] === "string" && numericPattern.test(sliderOptions[key])) {
                sliderOptions[key] = parseInt(sliderOptions[key], 10);
            }
        });

       
        const autoplaySettings = sliderOptions.auto_play > 0 ? { delay: 1000 * sliderOptions.auto_play } : false;     
        const loopEnabled = sliderOptions.loop === "true" || sliderOptions.loop === true || sliderOptions.loop === 1;     
        const centeredSlides = sliderOptions.mode === "true" || sliderOptions.mode === true;

        const swiperOptions = $.extend(true, {
            init: false,
            spaceBetween: sliderOptions.space,
            loop: loopEnabled,
            preventClicks: true,
            preventClicksPropagation: true,
            autoplay: autoplaySettings,
            centeredSlides: centeredSlides,
            speed: 2000, 
            navigation: {
                nextEl: this.sliderConfigElement.querySelector(".swiper-button-next"),
                prevEl: this.sliderConfigElement.querySelector(".swiper-button-prev")
            },
            pagination: {
                el: this.sliderConfigElement.querySelector(".swiper-pagination"),
                clickable: true
            },
            lazy: true,
            focusableElements: 'input, select, option, textarea, video, label',
            breakpoints: {
                320: {
                    slidesPerView: sliderOptions.mobile || 1,
                    spaceBetween: sliderOptions.space * 0.7
                },
                480: {
                    slidesPerView: sliderOptions.medium_down || 2,
                    spaceBetween: sliderOptions.space * 0.7
                },
                768: {
                    slidesPerView: sliderOptions.tablet || 2,
                    spaceBetween: sliderOptions.space * 0.7
                },
                992: {
                    slidesPerView: sliderOptions.laptop || 3,
                    spaceBetween: sliderOptions.space * 0.8
                },
                1400: {
                    slidesPerView: sliderOptions.desktop || 4
                }
            }
        }, sliderOptions.additionalOptions);


        const swiperContainer = this.sliderConfigElement.querySelector("[data-swiper-slider]");
        const swiperInstance = new Swiper(swiperContainer, swiperOptions);
        swiperInstance.on("init", () => {
            swiperInstance.update();
        });

        swiperInstance.init();
    }
});
}


if (!customElements.get('wdt-shoppable-video')) {
customElements.define('wdt-shoppable-video',class  WDT_Shoppablevideo extends HTMLElement{
    constructor() {
        super();     
        this.sliderConfigElement = this.querySelector("[data-slider-options]");    
        if (this.sliderConfigElement) this.initializeSlider();
    }

    initializeSlider() {
       
        const sliderOptionsData = this.sliderConfigElement.getAttribute("data-slider-options");
        if (!sliderOptionsData) return;
        const sliderOptions = $.extend(true, {
            effect: "slide",
            direction: "horizontal",
            autoplay: true,
            autoplaySpeed: 5,
            spaceBetween: 0, 
            additionalOptions: {}
        }, JSON.parse(sliderOptionsData));
       
        const numericPattern = /^\d+$/;
        Object.keys(sliderOptions).forEach((key) => {        
            if (typeof sliderOptions[key] === "string" && numericPattern.test(sliderOptions[key])) {
                sliderOptions[key] = parseInt(sliderOptions[key], 10);
            }
        });

       
        const autoplaySettings = sliderOptions.auto_play > 0 ? { delay: 1000 * sliderOptions.auto_play } : false;     
        const loopEnabled = sliderOptions.loop === "true" || sliderOptions.loop === true || sliderOptions.loop === 1;     
        const centeredSlides = sliderOptions.mode === "true" || sliderOptions.mode === true;

        const swiperOptions = $.extend(true, {
            init: false,
            spaceBetween: sliderOptions.space,
            loop: loopEnabled,
            preventClicks: true,
            preventClicksPropagation: true,
            autoplay: autoplaySettings,
            centeredSlides: centeredSlides,
            speed: 2000, 
            navigation: {
                nextEl: this.sliderConfigElement.querySelector(".swiper-button-next"),
                prevEl: this.sliderConfigElement.querySelector(".swiper-button-prev")
            },
            pagination: {
                el: this.sliderConfigElement.querySelector(".swiper-pagination"),
                clickable: true
            },
            lazy: true,
            focusableElements: 'input, select, option, textarea, video, label',
            breakpoints: {
                320: {
                    slidesPerView: sliderOptions.mobile || 1,
                },
                768: {
                    slidesPerView: sliderOptions.tablet || 2,
                },
                1200: {
                    slidesPerView: sliderOptions.laptop || 3,
                },
                1400: {
                    slidesPerView: sliderOptions.desktop || 4
                }
            }
        }, sliderOptions.additionalOptions);


        const swiperContainer = this.sliderConfigElement.querySelector("[data-swiper-slider]");
        const swiperInstance = new Swiper(swiperContainer, swiperOptions);
        swiperInstance.on("init", () => {
            swiperInstance.update();
        });

        swiperInstance.init();
    }
});
}

if (!customElements.get('wdt-gallery-slider')) {
customElements.define('wdt-gallery-slider',class  WDT_Gallery extends HTMLElement{
    constructor() {
        super();     
        this.sliderConfigElement = this.querySelector("[data-slider-options]");    
        if (this.sliderConfigElement) this.initializeSlider();
    }

    initializeSlider() {
       
        const sliderOptionsData = this.sliderConfigElement.getAttribute("data-slider-options");
        if (!sliderOptionsData) return;
        const sliderOptions = $.extend(true, {
            effect: "slide",
            direction: "horizontal",
            autoplay: true,
            autoplaySpeed: 5,
            spaceBetween: 0, 
            additionalOptions: {}
        }, JSON.parse(sliderOptionsData));
       
        const numericPattern = /^\d+$/;
        Object.keys(sliderOptions).forEach((key) => {        
            if (typeof sliderOptions[key] === "string" && numericPattern.test(sliderOptions[key])) {
                sliderOptions[key] = parseInt(sliderOptions[key], 10);
            }
        });

       
        const autoplaySettings = sliderOptions.auto_play > 0 ? { delay: 1000 * sliderOptions.auto_play } : false;     
        const loopEnabled = sliderOptions.loop === "true" || sliderOptions.loop === true || sliderOptions.loop === 1;     
        const centeredSlides = sliderOptions.mode === "true" || sliderOptions.mode === true;
        const swiperOptions = $.extend(true, {
            init: false,
            spaceBetween: sliderOptions.space,
            loop: loopEnabled,
            preventClicks: true,
            preventClicksPropagation: true,
            autoplay: autoplaySettings,         
             speed: 2000, 
            navigation: {
                nextEl: this.sliderConfigElement.querySelector(".swiper-button-next"),
                prevEl: this.sliderConfigElement.querySelector(".swiper-button-prev")
            },
            pagination: {
                el: this.sliderConfigElement.querySelector(".swiper-pagination"),
                clickable: true
            },
            lazy: true,
            focusableElements: 'input, select, option, textarea, video, label',
            breakpoints: {
               320: {
                    slidesPerView: sliderOptions.mobile || 1,
                    spaceBetween: sliderOptions.space * 0.6
                },
                768: {
                    slidesPerView: sliderOptions.tablet || 2,
                    spaceBetween: sliderOptions.space * 0.8
                },
                992: {
                    slidesPerView: sliderOptions.laptop || 4,
                    spaceBetween: sliderOptions.space * 0.7
                },
                1400: {
                    slidesPerView: sliderOptions.desktop || 6,
                    spaceBetween: sliderOptions.space
                }
            }
        }, sliderOptions.additionalOptions);


        const swiperContainer = this.sliderConfigElement.querySelector("[data-swiper-slider]");
        const swiperInstance = new Swiper(swiperContainer, swiperOptions);
        swiperInstance.on("init", () => {
            swiperInstance.update();
        });

        swiperInstance.init();
    }
});
}  

if (!customElements.get('wdt-testimonial-slider')) {
customElements.define('wdt-testimonial-slider',class  WDT_Testimonial extends HTMLElement {
    constructor() {
        super();      
        this.sliderConfigElement = this.querySelector("[data-slider-options]");        
        if(this.sliderConfigElement)this.initializeSlider();
    }

    initializeSlider() {        
        const sliderOptionsData = this.sliderConfigElement.getAttribute("data-slider-options");
        if (sliderOptionsData === null || sliderOptionsData === "") return null;
        const sliderOptions = $.extend(true, {
            effect: "slide",
            direction: "horizontal",
            autoplay: true,
            autoplaySpeed: 5,
            spaceBetweenSlides: 0,            
            additionalOptions: {}
        }, JSON.parse(sliderOptionsData));
        
        const numericPattern = /^\d+$/;
        Object.keys(sliderOptions).forEach((key) => {
            if (typeof sliderOptions[key] === "string" && numericPattern.test(sliderOptions[key])) {
                sliderOptions[key] = parseInt(sliderOptions[key], 10);
            }
        });

        let autoplaySettings = false;
        if (sliderOptions.auto_play > 0) {
            autoplaySettings = { delay: 1000 * sliderOptions.auto_play };
        }
        let loopEnabled = false;
        if (sliderOptions.loop === "true" || sliderOptions.loop === true || sliderOptions.loop === 1) {
            loopEnabled = true;
        }

        let centeredSlides = false;
        if (sliderOptions.mode === "true" || sliderOptions.mode === true ) {
            centeredSlides = true;
        }

        const swiperOptions = $.extend(true, {
            init: false,
            spaceBetween: sliderOptions.space,
            loop: loopEnabled,
            preventClicks: true,
            preventClicksPropagation: true,
            autoplay: autoplaySettings,
            centeredSlides: centeredSlides,
           speed: 2000, 
            navigation: {
                nextEl: this.sliderConfigElement.querySelector(".swiper-button-next"),
                prevEl: this.sliderConfigElement.querySelector(".swiper-button-prev")
            },
            pagination: {
                el: this.sliderConfigElement.querySelector(".swiper-pagination"),
                clickable: true
            },
            lazyLoading: true,
            focusableElements: 'input, select, option, textarea, video, label',
            breakpoints: {
                320: {
                    slidesPerView: sliderOptions.mobile || 1,
                    spaceBetween: 10
                },
                768: {
                    slidesPerView: sliderOptions.tablet || 2,
                    spaceBetween: 20
                },
                992: {
                    slidesPerView: sliderOptions.laptop || 3,
                    spaceBetween: 20
                },
                1440: {
                    slidesPerView: sliderOptions.desktop || 4
                }
             }
        }, sliderOptions.additionalOptions);

        const swiperContainer = this.sliderConfigElement.querySelector("[data-swiper-slider]");
        const swiperInstance = new Swiper(swiperContainer, swiperOptions);

        swiperInstance.on("init", () => {
            swiperInstance.update();
        });

        swiperInstance.init();
    }
});
}


function cardSwatch() {
  document.body.addEventListener("click", function (event) {
    const swatch = event.target.closest(".item-swatch span");
    if (!swatch) return;
    const cardMain = swatch.closest(".card-main");
    if (cardMain) {
      const featuredMedia = cardMain.querySelector(".card__inner .featured-media");
      if (featuredMedia) {
        featuredMedia.setAttribute("srcset", swatch.dataset.image);
      }
      const cardSwatch = swatch.closest(".card-swatch");
      if (cardSwatch && cardSwatch.classList.contains("color")) {
        const variant = swatch.dataset.id;
        const variantInput = cardMain.querySelector(".product-variant-id");
        if (variantInput) {
          variantInput.value = variant;
        }            
      }
    }
  });
}

if (!customElements.get('vertical-bar')) {
  customElements.define('vertical-bar', class VerticalBar extends HTMLElement {
    constructor() {
    super();
    this.container = document.querySelector(".vertical-marquee-selector");
    // Initialize Swiper
    const swiper = new Swiper(this.container, {
      direction: 'vertical', 
      loop: true,  
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
      speed: 1000, 
      navigation: {
        nextEl: this.querySelector(".swiper-button-next"),
        prevEl: this.querySelector(".swiper-button-prev"),
      },
    });

  }
  });
}


if (!customElements.get('compare-banner')) {
  customElements.define('compare-banner', class compareBanner extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    this.initSlider();
  }

  initSlider() {
    const container = this.querySelector('.compare-container');
    const slider = this.querySelector('.drag-slider');
    if (container && slider) {      
      slider.addEventListener('input', (e) => {       
        container.style.setProperty('--position', `${e.target.value}%`);       
      });
    } else {
      console.error('Container or slider not found'); 
    }
  }
});
}

if (!customElements.get('gallery-component')) {
  customElements.define('gallery-component', class GalleryComponent extends HTMLElement {
  constructor() {
    super();
    this.imageBlocks = [];
    this.contentBlocks = [];
  }

  connectedCallback() {
    this.imageBlocks = this.querySelectorAll(".media-gallery .media-image");
    this.contentBlocks = this.querySelectorAll(
      ".gallery-content .content-item"
    );
    this.initialize();
  }

  initialize() {
    if (this.imageBlocks.length > 0 && this.contentBlocks.length > 0) {
      this.imageBlocks[1].classList.add("highlight");
      this.contentBlocks[1].classList.add("highlight");
    }

    this.contentBlocks.forEach((contentBlock, index) => {
      contentBlock.addEventListener("mouseover", () => {
        this.clearHighlights();
        this.setHighlight(index);
      });
    });
  }

  clearHighlights() {
    this.imageBlocks.forEach((block) => block.classList.remove("highlight"));
    this.contentBlocks.forEach((block) => block.classList.remove("highlight"));
  }

  setHighlight(index) {
    if (this.imageBlocks[index] && this.contentBlocks[index]) {
      this.imageBlocks[index].classList.add("highlight");
      this.contentBlocks[index].classList.add("highlight");
    }
  }
});
                        }

if (!customElements.get('dropdown-tabs')) {
  customElements.define('dropdown-tabs', class DropdownTabs extends HTMLElement {
  constructor() {
    super();
    this.dropdown = this.querySelector(".dropdown-toggle");
    this.dropdownItems = this.querySelectorAll(".item-trigger");
    this.tabLinks = this.querySelectorAll(".tab-content .tab-pane");
    this.tabs = this.querySelectorAll('[role="tab"]');
    this.panels = this.querySelectorAll('[role="tabpanel"]');

    this.updateDropdown = this.updateDropdown.bind(this);
    this.handleItemClick = this.handleItemClick.bind(this);
    this.handleKeyDown = this.handleKeyDown.bind(this);
    this.activateTab = this.activateTab.bind(this);
  }

  connectedCallback() {
    const activeItem = this.querySelector(".item-trigger.active");
    if (activeItem) {
      this.dropdown.textContent = activeItem.textContent;
    }

    this.dropdownItems.forEach((item) => {
      item.addEventListener("click", this.handleItemClick);
    });

    this.tabs.forEach((tab, index) => {
      tab.addEventListener("keydown", (e) => this.handleKeyDown(e, index));
      tab.addEventListener("click", () => this.activateTab(tab));
    });
  }

  updateDropdown(selectedTabText, tabId) {
    // Update dropdown label
    this.dropdown.textContent = selectedTabText;

    // Update tab links
    this.tabLinks.forEach((link) => {
      if (link.getAttribute("id") === tabId) {
        link.classList.add("show", "active");
      } else {
        link.classList.remove("show", "active");
      }
    });

    // Update dropdown items
    this.dropdownItems.forEach((item) => {
      if (item.getAttribute("href").substring(1) === tabId) {
        item.classList.add("active");
      } else {
        item.classList.remove("active");
      }
    });
  }

  handleItemClick(event) {
    event.preventDefault();
    const target = event.target.closest("a");
    if (!target) return;
    const selectedTabText = target.textContent.trim();
    const tabId = target.getAttribute("href").substring(1);
    this.updateDropdown(selectedTabText, tabId);
  }

  handleKeyDown(event, index) {
    let newIndex;
    if (event.key === "ArrowRight") {
      newIndex = (index + 1) % this.tabs.length;
    } else if (event.key === "ArrowLeft") {
      newIndex = (index - 1 + this.tabs.length) % this.tabs.length;
    } else if (event.key === "Home") {
      newIndex = 0;
    } else if (event.key === "End") {
      newIndex = this.tabs.length - 1;
    } else if (event.key === "Enter" || event.key === " ") {
      this.activateTab(this.tabs[index]);
    }
    if (newIndex !== undefined) {
      this.tabs[newIndex].focus();
    }
  }

  activateTab(selectedTab) {
    this.tabs.forEach((tab) => {
      const isActive = tab === selectedTab;
      tab.setAttribute("aria-selected", isActive);
      tab.setAttribute("tabindex", isActive ? "0" : "-1");
    });

    this.panels.forEach((panel) => {
      const isVisible = panel.getAttribute("aria-labelledby") === selectedTab.id;
      panel.hidden = !isVisible;
    });
  }
});
}


if(window.routes.cartType == 'page'){
if (!customElements.get('add-to-cart-form')) {
  customElements.define('add-to-cart-form',
    class AddToCartForm extends HTMLElement {
       constructor() {
          super();
          this.form = this.querySelector('form');         
          const selectElement = this.form.querySelector('[name=id]');
          this.submitButton = this.querySelector('[type="button"]');
          const variantSelect = this.form.querySelector('select[name="id"]');
          const variantId = selectElement ? selectElement.value : variantSelect;                 
           this.submitButton.addEventListener('click', () => {
           this.form.submit();
           });

        }
    }
  );
}
}
class ProductGallery {
  constructor(container = document) {
    this.container = container;
    this.thumbnailListContainer = container.querySelector(".product-thumbnails");
    this.thumbnailDirection = container.querySelector("[data-direction]");
    this.mainListContainer = container.querySelector(".product-media-gallery");

    if (!this.thumbnailListContainer || !this.mainListContainer) {
     // console.error("Swiper initialization skipped: Required containers not found.");
      return;
    }

    const directionAttribute = this.thumbnailDirection?.dataset.direction?.trim();
    this.thumbDirection =
      directionAttribute === "vertical"
        ? "vertical"
        : directionAttribute === "stacked"
        ? "stacked"
        : "horizontal";

    this.thumbSwiper = null;
    this.gallerySwiper = null;

    this.currentWindowWidth = window.innerWidth;
    this.currentWindowHeight = window.innerHeight;

    this.updateContainerHeight = this.updateContainerHeight.bind(this);
    this.init();

    window.addEventListener("resize", this.handleResize.bind(this));
  }

  init() {
    if (this.thumbDirection === "vertical") {
      this.initThumbVerticalSwiper("vertical");
     // this.initThumbSwiper("vertical");
      this.initGallerySwiper();
      this.updateContainerHeight();
    } else if (this.thumbDirection === "horizontal") {
      this.initThumbSwiper("horizontal");
      this.initGallerySwiper();
    } else if (this.thumbDirection === "stacked") {
      this.destroySwipers();
      this.initGalleryStacked();
    }

    this.syncThumbnailClicks();
    this.toggleActiveMediaPreview();
  }

  updateContainerHeight() {
    // this.currentWindowWidth = window.innerWidth;
    // this.currentWindowHeight = window.innerHeight;

    // if (this.thumbDirection === "vertical") {
    //   const verticalContainerHeight = this.mainListContainer.offsetHeight;
    //   this.thumbnailListContainer.style.height = `${verticalContainerHeight}px`;
    //   console.log(
    //     `Updated verticalContainerHeight: ${verticalContainerHeight}, Current Window: ${this.currentWindowWidth}x${this.currentWindowHeight}`
    //   );
    // }
  }

  handleResize() {
    this.destroySwipers(); 
    this.init(); 
    this.updateContainerHeight(); 
  }

  initThumbVerticalSwiper(direction) {
    this.thumbSwiper = new Swiper(this.thumbnailListContainer, {
      spaceBetween: 20,
      slidesPerView: 4,
      slidesPerGroup: 1,
      loop: true,
      direction: direction,      
      navigation: {
        nextEl: ".thumb-next",
        prevEl: ".thumb-prev",
      },
      breakpoints: {
      1440: { slidesPerView: 4, slidesPerGroup: 1 },
      1199: { slidesPerView: 3, slidesPerGroup: 1 },
      992: { slidesPerView: 3, slidesPerGroup: 1 },
      900: { slidesPerView: 4, slidesPerGroup: 1 },
      600: { slidesPerView: 3, spaceBetween: 15, slidesPerGroup: 1 },
      450: { slidesPerView: 3, spaceBetween: 10, direction: "horizontal", slidesPerGroup: 1 },
      320: { slidesPerView: 2, spaceBetween: 10, direction: "horizontal", slidesPerGroup: 1 },
      },
    });

  //   // Add event listeners to thumbnails for slide movement
  // const thumbnailSlides = this.thumbnailListContainer.querySelectorAll(".swiper-slide");
  // thumbnailSlides.forEach((slide, index) => {
  //   slide.addEventListener("click", () => {
  //     this.thumbSwiper.slideTo(index); // Move to the clicked slide
  //   });
  // });
    
  }

  initThumbSwiper(direction) {
    this.thumbSwiper = new Swiper(this.thumbnailListContainer, {
      spaceBetween: 15,
     // slidesPerView: direction === "vertical" ? 3 : 4,
      slidesPerView: 4,
      direction: direction,
      navigation: {
        nextEl: ".thumb-next",
        prevEl: ".thumb-prev",
      },
      breakpoints: {
        320: {
          slidesPerView: 2,
          spaceBetween: 10,
        },
        480: {
          slidesPerView: 3,
        },
        992: {
          slidesPerView: 3,
        },
        1200: {
          slidesPerView: 4,
        },
      },
    });
  }

  initGallerySwiper() {
    this.gallerySwiper = new Swiper(this.mainListContainer, {
      spaceBetween: 10,
      slidesPerView: 1,
      loop: false,
      effect: "fade",
      autoHeight: true,
      fadeEffect: { crossFade: true },
      navigation: {
        nextEl: ".main-next",
        prevEl: ".main-prev",
      },
        pagination: {
                el: ".swiper-pagination-main",
                clickable: true
            },
      thumbs: { swiper: this.thumbSwiper },
    });
  }

  destroySwipers() {
    if (this.thumbSwiper) {
      this.thumbSwiper.destroy(true, true);
      this.thumbSwiper = null;
    }
    if (this.gallerySwiper) {
      this.gallerySwiper.destroy(true, true);
      this.gallerySwiper = null;
    }
  }

  initGalleryStacked() {
    this.mainListContainer.classList.add("stacked-gallery");
    const slides = this.mainListContainer.querySelectorAll(".swiper-slide");
    slides.forEach((slide) => {
      slide.classList.add("stacked-slide");
    });
  }

  syncThumbnailClicks() {
    const thumbnailSlides = document.querySelectorAll(".thumbnail-slide");
    thumbnailSlides.forEach((el) => {
      el.addEventListener("click", (event) => {
        const mediaId = event.currentTarget.getAttribute("data-media-id");
        this.gallerySwiper?.slides.forEach((slide, index) => {
          if (slide.getAttribute("data-media-id") === mediaId) {
            this.gallerySwiper.slideTo(index);
          }
        });
      });
    });
  }

  toggleActiveMediaPreview() {
    const mediaButtons = document.querySelectorAll(".product_media_preview");
    mediaButtons.forEach((button) => {
      button.addEventListener("click", function () {
        this.closest(".product-active-media").classList.toggle("active");
      });
    });

    const mediaContainers = document.querySelectorAll(".product-internal-video");
    mediaContainers.forEach((mediaContainer) => {
      mediaContainer.addEventListener("click", function () {
        const video = mediaContainer.querySelector("video");

        if (video) {
          mediaContainers.forEach((otherMedia) => {
            const otherVideo = otherMedia.querySelector("video");
            if (otherVideo && otherVideo !== video && !otherVideo.paused) {
              otherVideo.pause();
            }
          });

          video.paused ? video.play() : video.pause();
        }
      });
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const productGallery = new ProductGallery();
});


if (!customElements.get('product-model')) {
  customElements.define('product-model', class ProductModelElement extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    this.addEventListener("click", this.handleModelClick.bind(this));
    this.loadShopifyXR();
  }

  loadShopifyXR() {
    Shopify.loadFeatures([
      {
        name: "shopify-xr",
        version: "1.0",
        onLoad: this.setupShopifyXR.bind(this),
      },
    ]);
  }

  setupShopifyXR(errors) {
    if (errors) return;
    if (!window.ShopifyXR) {
      document.addEventListener("shopify_xr_initialized", () =>
        this.setupShopifyXR()
      );
      return;
    }

    document.querySelectorAll('[id^="ProductJSON-"]').forEach((modelJSON) => {
      window.ShopifyXR.addModels(JSON.parse(modelJSON.textContent));
      modelJSON.remove(); // Remove JSON script after processing
    });

    window.ShopifyXR.setupXRElements();
  }

  handleModelClick() {
    if (!this.classList.contains("model-loaded")) {
      this.loadContent();
      this.classList.add("model-loaded"); // Prevent multiple loads
    }
  }

  // Load the 3D model viewer UI
  loadContent() {
    Shopify.loadFeatures([
      {
        name: "model-viewer-ui",
        version: "1.0",
        onLoad: this.setupModelViewerUI.bind(this),
      },
    ]);
  }

  // Setup the 3D model viewer UI
  setupModelViewerUI(errors) {
    if (errors) return;
    const modelViewerElement = this.querySelector("model-viewer");
    if (modelViewerElement) {
      this.modelViewerUI = new Shopify.ModelViewerUI(modelViewerElement);
    }
  }
});
}


if (!customElements.get('quantity-editor')) {
  customElements.define('quantity-editor', class QuantityEditor extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    const quantityInput = this.querySelector('input[name="quantity"]');
    this.incrementBtn = this.querySelector(".increment-btn");
    this.decrementBtn = this.querySelector(".decrement-btn");
    this.qtyAlert = this.querySelector(".qty-status");

    // Ensure that all necessary elements exist before adding event listeners
    if (quantityInput && this.incrementBtn && this.decrementBtn) {
      this.incrementBtn.addEventListener("click", () =>
        this.editQuantity(event, quantityInput, true)
      );
      this.decrementBtn.addEventListener("click", () =>
        this.editQuantity(event, quantityInput, false)
      );
    } else {
      console.error("QuantityEditor: Missing required elements (input or buttons).");
    }
  }

  // Method to update the quantity
  editQuantity(event, inputElement, increment) {       
    let currentQuantity = parseInt(inputElement.value);
    if (isNaN(currentQuantity)) currentQuantity = 1;

    // Update quantity
    currentQuantity = increment ? currentQuantity + 1 : currentQuantity - 1;

    // Get min and max values
    const minValue = inputElement.min || 1;
    const maxValue = inputElement.max || Infinity;
    const min = parseInt(minValue, 10);
    const max = parseInt(maxValue, 10);

    const qtyStatusOnChange = document.querySelector(".qty-status");
    
    if (currentQuantity > max) {
      currentQuantity = max;
      this.incrementBtn.classList.add("disabled");    
       qtyStatusOnChange.classList.remove("invisible"); 
      if (this.qtyAlert) {
        this.qtyAlert.textContent = window.cartStrings.quantityError.replace("[quantity]",max);         
      }
    } else {
      if (this.qtyAlert) {
        this.qtyAlert.textContent = " ";        
      }
      this.incrementBtn.classList.remove("disabled");         
    }

    if (currentQuantity <= min) {
      currentQuantity = min;
      this.decrementBtn.classList.add("disabled");      
    } else {
      this.decrementBtn.classList.remove("disabled");   
       qtyStatusOnChange.classList.add("invisible"); 
    }
    if(currentQuantity === max) { qtyStatusOnChange.classList.remove("invisible"); }   
    inputElement.value = currentQuantity;
    console.log("currentQuantity"+currentQuantity);
    event.preventDefault();
    //event.stopPropagation();
    this.updateTotalPrice(currentQuantity);
  }

  updateTotalPrice(quantity) {
  //  console.log("Updating total price for quantity:", quantity);
    // Logic for updating total price can be added here.
  }
});
}

let isQuickViewOpen = false;

if (!customElements.get('variant-selector')) {
  customElements.define('variant-selector', class VariantSelector extends HTMLElement {
  constructor(modalContent = null) {
    super();
    this.modalContent = modalContent || document; 
    this.init();
  }

  init(modalContent = null) {
    this.modalContent = modalContent || this.modalContent || document;
    
    const url = window.location.search;
    const urlParams = new URLSearchParams(url);
    const currentVariant = urlParams.get("variant");

     this.addToCartButton = this.modalContent.querySelector ("#addToCart");
     this.variantIdField = this.modalContent.querySelector("#variant-id");
    
    this.isDropdown = this.querySelector("select");

    if (this.isDropdown) {
      this.querySelectorAll("select").forEach((selectBox) => {
        selectBox.addEventListener("change", this.onDropdownChange.bind(this));
      });
    } else {
      this.querySelectorAll(".variant-options .variant-option-item").forEach((item) => {
        item.addEventListener("click", this.onSwatchOptionClick.bind(this));
      });
    }

    this.callChoosenOptions();
  }

  onSwatchOptionClick(event) {
    const parentUl = event.target.closest(".variant-options");
    parentUl.querySelectorAll(".variant-option-item").forEach((item) => {
      item.classList.remove("selected");
    });
    const optionItem = event.target.closest(".variant-option-item");

    if (optionItem) {
      optionItem.classList.add("selected");
    }

    this.onVariantChange();
    this.filterOptionValues();
  }

  onDropdownChange() {
    this.onVariantChange();
    this.filterOptionValues();
  }

  callChoosenOptions() {
    if (this.isDropdown) {
      this.options = Array.from(this.querySelectorAll("select"), (select) => select.value);
    } else {
      this.options = Array.from(this.querySelectorAll(".variant-options"), (ul) => {
        const selected = ul.querySelector(".selected");
        return selected ? selected.getAttribute("data-value") : null;
      });
    }

    if (this.options.includes(null)) {
      this.currentVariant = null;
      return;
    }
  }

  filterOptionValues() {
    const variantData = this.getVariantJSON();
    const selectedOption1 = this.options[0];
    const option2List = this.querySelector('[data-option-index="1"]');
    const option3List = this.querySelector('[data-option-index="2"]');
    
    // Option 2 filtering
    if (option2List) {
      option2List.querySelectorAll(".variant-option-item").forEach((item) => {
        const option2Value = item.getAttribute("data-value");
        const isOption2Available = variantData.some(
          (variant) =>
            variant.options[0] === selectedOption1 &&
            variant.options[1] === option2Value &&
            variant.available
        );

        if (isOption2Available) {
          item.style.display = "block";
          item.classList.remove("variant-unavailable");
        } else {
          item.style.display = "none";
          item.classList.add("variant-unavailable");
        }
      });
    }

    // Option 3 filtering
    if (option3List) {
      const selectedOption2 = this.options[1];

      option3List.querySelectorAll(".variant-option-item").forEach((item) => {
        const option3Value = item.getAttribute("data-value");
        const isOption3Available = variantData.some(
          (variant) =>
            variant.options[0] === selectedOption1 &&
            variant.options[1] === selectedOption2 &&
            variant.options[2] === option3Value &&
            variant.available
        );

        if (isOption3Available) {
          item.style.display = "block";
          item.classList.remove("variant-unavailable");
        } else {
          item.style.display = "none";
          item.classList.add("variant-unavailable");
        }
      });
    }

    this.callChoosenVariants();
    this.updateAddToCartButton();
  }

  updateAddToCartButton() {
    const qtyStatusDiv = this.modalContent.querySelector(".qty-status");

    if (qtyStatusDiv) {
      qtyStatusDiv.innerHTML = "";
    }

    if (this.currentVariant) {
      const qtySelector = this.closest("main-product-form").querySelector(".quantity-input");
      const variantDivs = this.modalContent.querySelectorAll(".product-variants-selector-select div");
      let matchingVariantDiv = null;

      variantDivs.forEach((variantDiv) => {
        if (variantDiv.getAttribute("value") === this.currentVariant.id.toString()) {
          matchingVariantDiv = variantDiv;
        }
      });

      if (matchingVariantDiv) {
        const inventoryQuantity = parseInt(matchingVariantDiv.getAttribute("data-inventory-quantity"));
        const inventoryManagement = matchingVariantDiv.getAttribute("data-inventory-management");
        const inventoryPolicy = matchingVariantDiv.getAttribute("data-inventory-policy");
        const available = matchingVariantDiv.getAttribute("data-available") === "true";

        if (available) {
          if (inventoryQuantity === 0 && inventoryManagement && inventoryPolicy !== "continue") {
            this.addToCartButton.disabled = true;
            this.addToCartButton.textContent = window.variantStrings.soldOut;
          } else {
            this.addToCartButton.disabled = false;
            this.addToCartButton.textContent = window.variantStrings.addToCart;

            if (inventoryManagement) {
              qtySelector.setAttribute("max", inventoryQuantity);
            } else {
              qtySelector.removeAttribute("max");
            }
          }
        } else {
          this.addToCartButton.disabled = true;
          this.addToCartButton.textContent = window.variantStrings.soldOut;
        }
      } else {
        console.error("Matching variant not found.");
        this.addToCartButton.disabled = true;
        this.addToCartButton.textContent = window.variantStrings.unavailable;
      }
    } else {
      this.addToCartButton.disabled = true;
      this.addToCartButton.textContent = window.variantStrings.unavailable;
    }
  }

  onVariantChange() {
    this.callChoosenOptions();
    this.callChoosenVariants();

    if (this.currentVariant) {
      this.updateURL();
      this.updateFormID();
      this.updatePrice();
      this.updateProductGallery();

      const pickupAvailabilityCheck = this.modalContent.querySelector("product-availability-check");
      if (pickupAvailabilityCheck && typeof pickupAvailabilityCheck.refreshProduct === "function") {
        pickupAvailabilityCheck.refreshProduct(this.currentVariant);
      }

      const stickyCartForm = document.querySelector("sticky-cart-form");
    
      if (stickyCartForm && this.currentVariant) {
        // Dispatch the custom event
        window.dispatchEvent(new Event("stikcyVariant"));
      
        // Synchronize the variant to the sticky bar
        syncVariantToStickyBar(this.currentVariant);
      }
     

      
      this.updateAddToCartButton();
    } else {
      this.addToCartButton.disabled = true;
      this.addToCartButton.textContent = window.variantStrings.unavailable;
    }
  }

  getVariantJSON() {
    this.variantData = this.variantData || JSON.parse(this.querySelector('[type="application/json"]').textContent);
    return this.variantData;
  }

  callChoosenVariants() {
    const variantData = this.getVariantJSON();
    if (!variantData) return;

    this.currentVariant = variantData.find((variant) =>
      variant.options.every((option, index) => this.options[index] === option)
    );
  }

  updateURL() {
    if (!this.currentVariant || isQuickViewOpen) return;
    window.history.replaceState({}, "", `${this.dataset.url}?variant=${this.currentVariant.id}`);
  }

  updateFormID() {
    const formInput = this.modalContent.querySelector("#product-form input[name='id']");
    if (formInput && this.currentVariant) {
      formInput.value = this.currentVariant.id;
    }
  }

  updatePrice() {
    fetch(`${this.dataset.url}?variant=${this.currentVariant.id}&section_id=${this.dataset.section}`)
      .then((response) => response.text())
      .then((responseText) => {
        const id = `price-${this.dataset.section}`;
        const sku = `sku-${this.dataset.section}`;
        const html = new DOMParser().parseFromString(responseText, "text/html");
          const newPrice = html.querySelector(`#${id}`);
          const oldPrice = this.modalContent.querySelector(`#${id}`);
        
          const newSku = html.querySelector(`#${sku}`);
          const oldSku = this.modalContent.querySelector(`#${sku}`);
        

        if (oldPrice && newPrice) oldPrice.innerHTML = newPrice.innerHTML;
        if (oldSku && newSku) oldSku.innerHTML = newSku.innerHTML;
      });
  }

  updateProductGallery() {
    const mediaGalleryDiv = this.modalContent.querySelector("wdt-main-media");
    if (!mediaGalleryDiv) return;

    const swiperSliderInit = mediaGalleryDiv.querySelector(".product-media-gallery");
    if (!swiperSliderInit || !this.currentVariant.featured_media) return;

    const featuredMediaId = this.currentVariant.featured_media.id;
    const gallerySwiper = swiperSliderInit.swiper;
   if (!gallerySwiper) return;
    gallerySwiper.slides.forEach((slide, index) => {
      const mediaId = slide.getAttribute("data-media-id");
      if (mediaId && mediaId === `${featuredMediaId}`) {
        gallerySwiper.slideTo(index);
      }
    });
  }
});
}


if (!customElements.get('recipient-form')) {
  customElements.define('recipient-form', class RecipientForm extends HTMLElement {
  constructor() {
    super();
    this.checkBox = this.querySelector(
      `#Recipient-checkbox-${this.dataset.sectionId}`
    );

    if (!this.checkBox) {
      return;
    }

    this.checkBox.addEventListener("click", (e) => {
      e.preventDefault();
      this.onChange();
    });
  }

  onChange = () => {
    const recipientForm = this.closest(".recipient-form");
    if (!recipientForm) {
      return;
    }

    const formCheckBox = this.querySelector(
      `#Recipient-checkbox-${this.dataset.sectionId}`
    );
    const formContaner = recipientForm.querySelector(".gift-card-form");

    if (formCheckBox.hasAttribute("checked")) {
      formCheckBox.removeAttribute("checked");
    } else {
      formCheckBox.setAttribute("checked", true);
    }

    if (recipientForm.classList.contains("active")) {
      setTimeout(() => {
        recipientForm.classList.remove("active");
      }, 200);
    } else {
      recipientForm.classList.add("active");
    }
  };
});
}
                        

if (!customElements.get('product-recommendations')) {
  customElements.define('product-recommendations', class ProductRecommendations extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    this.loadRecommendations(this.dataset.productId);
  }

  loadRecommendations(productId) {
    fetch(`${this.dataset.url}&product_id=${productId}&section_id=${this.dataset.sectionId}`)
      .then(response => response.text())
      .then(text => {
        const html = document.createElement("div");
        html.innerHTML = text;

        const recommendations = html.querySelector("product-recommendations");

        if (recommendations?.innerHTML.trim().length) {
          this.innerHTML = recommendations.innerHTML;
        }

        const recommendationItems = html.querySelector(".recommendation-items");

        if (recommendationItems) {
          $(".related-products").closest(".shopify-section").removeClass("d-none");
        }
   
         if (recommendationItems) {
          this.classList.add("product-recommendations--loaded");
          this.initSlider();
        }

        if (html.querySelector(".complementary-items")) {
          this.classList.add("product-complementary--loaded");
          this.complementarySlider();
        }
        
        this.initQuickViewButtons();
      })
      .catch(e => console.error("Error loading recommendations:", e));
  }

  initSlider() {
    const slider = this.querySelector("[data-swiper-slider]");
    const sliderList = this.querySelectorAll(".recommendation-items");
    if (!slider || sliderList.length === 0) return;

    const sliderOptions = slider.parentElement.getAttribute("data-slider-options");
    if (!sliderOptions) {
      console.warn("Slider options not found.");
      return;
    }

    const options = JSON.parse(sliderOptions);
    const parsedOptions = this.parseSliderOptions(options);

    new Swiper(slider, {
      loop: parsedOptions.loop,
      autoplay: parsedOptions.autoplay ? { delay: parsedOptions.autoplay, disableOnInteraction: false } : false,
      centeredSlides: parsedOptions.centeredSlides,
      navigation: {
        nextEl: slider.parentElement.querySelector(".swiper-button-next"),
        prevEl: slider.parentElement.querySelector(".swiper-button-prev"),
      },
      pagination: {
        el: slider.parentElement.querySelector(".swiper-pagination"),
        clickable: true,
        renderBullet: (index, className) => `<span class="${className} page-link rounded-circle m-1 p-1"></span>`,
      },     
      lazy: { loadOnTransitionStart: true },
      slidesPerView: parsedOptions.slidesToShow,
      spaceBetween: parsedOptions.spaceBetween,
      speed: 2000,
      breakpoints: {
        320: {
                    slidesPerView: options.mobile || 1,
                    spaceBetween: 10
                },
                576: {
                    slidesPerView: options.tablet || 2,
                    spaceBetween: 20
                },
                992: {
                    slidesPerView: options.laptop || 3,
                    spaceBetween: 20
                },
                1200: {
                    slidesPerView: options.desktop || 4
                }

        
      },
    });
  }

  parseSliderOptions(options) {
    Object.keys(options).forEach(key => {
      if (typeof options[key] === "string" && /^\d+$/.test(options[key])) {
        options[key] = parseInt(options[key], 10);
      }
    });

    return {
      autoplay: options.auto_play > 0 ? options.auto_play * 1000 : false,
      loop: options.loop === "true" || options.loop === true,
      centeredSlides: options.mode === "true" || options.mode === true,
      pagination: options.dots === "true" || options.dots === true,
      slidesToShow: options.desktop,
      spaceBetween: options.space,
    };
  }

  complementarySlider() {
    const complementaryContainer = document.getElementById("complementary-slideshow");
    if (!complementaryContainer) return;

    new Swiper(complementaryContainer, {
      slidesPerView: 1,
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
      speed: 1000,
      navigation: {
        nextEl: complementaryContainer.parentElement.querySelector('.swiper-button-next'),
        prevEl: complementaryContainer.parentElement.querySelector('.swiper-button-prev'),
      },
    });
  }

  //QuickBTNS
  initQuickViewButtons() {
  const quickViewButtons = this.querySelectorAll('.quick-view-btn');  
   quickViewButtons.forEach(button => {
  button.addEventListener('click', () => { 
    const productUrl = button.getAttribute('data-product-url');
    const quickViewContent = document.getElementById('quickViewContent'); // Offcanvas body content
    quickViewContent.innerHTML = 'Loading...';
    isQuickViewOpen = true;
    // Fetch product data
    fetch(productUrl)
      .then(response => response.text())
      .then(data => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(data, 'text/html');
        const productInfoElement = doc.querySelector('product-template');

        if (productInfoElement) {
          updateDOM(productInfoElement);
          quickViewContent.innerHTML = productInfoElement.innerHTML;

          // Initialize Bootstrap Offcanvas
          const quickViewOffcanvas = new bootstrap.Offcanvas(document.getElementById('quickViewOffcanvas'));
          document.getElementById('quickViewOffcanvas').addEventListener('hidden.bs.offcanvas', () => {
            isQuickViewOpen = false;
          });

          quickViewOffcanvas.show();
          this.initializeModalContent(quickViewContent); // `this` correctly refers to the class instance
        } else {
          quickViewContent.innerHTML = 'Product information not found.';
        }
      })
      .catch(error => {
        quickViewContent.innerHTML = 'Sorry, an error occurred while loading the product.';
        console.error('Error fetching product data:', error);
      });
  });
});
    
}

initializeModalContent(modalContent) {
  if (modalContent) {    
    new ProductGallery(modalContent);
    const variantSelectors = modalContent.querySelectorAll('variant-selector');    
    variantSelectors.forEach((variantSelectorEl) => {
      if (typeof variantSelectorEl.init === 'function') {
        variantSelectorEl.init(modalContent);
        //console.log("A"+modalContent.innerHTML);
      } else {
        const variantSelector = new VariantSelector(modalContent);
        if (typeof variantSelector.init === 'function') {
          variantSelector.init(modalContent);
        } else {
          console.warn("VariantSelector instance does not have an init method.");
        }      
      }
    });
  } else {
    console.error("Modal content not found for ProductGallery initialization.");
  }
}
 
   
});
}


if (!customElements.get("gift-card-recipient-form")) {
  customElements.define(
    "gift-card-recipient-form",
    class GiftCardRecipientForm extends HTMLElement {
      constructor() {
        super();

        // Button to trigger section fetch
        const fetchButton = this.querySelector(".fetch-gift-form");
        if (fetchButton) {
          fetchButton.addEventListener(
            "click",
            this.onClickFetchForm.bind(this)
          );
        }

        // Create the clear button but don't append it here
        this.clearButton = document.createElement("div");
        this.clearButton.textContent = wdtTheme.strings.clear_form;
        this.clearButton.classList.add("clear-form-button");
        this.clearButton.style.display = "none";
        this.clearButton.addEventListener("click", this.clearForm.bind(this));
      }

   
      fetchForm(variantId) {
        let rootUrl = this.dataset.rootUrl;
        if (!rootUrl.endsWith("/")) {
          rootUrl += "/";
        }

        const formSectionUrl = `${rootUrl}?sections=${this.dataset.sectionId}`;
   
        fetch(formSectionUrl)
          .then((response) => {
            if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json(); // Parse the response as JSON
          })
          .then((data) => {
            const htmlString = data["gift-card-recipient-form"];   
            const sectionInnerHTML = new DOMParser()
              .parseFromString(htmlString, "text/html")
              .querySelector(".recipient-form");

            if (sectionInnerHTML) {             
              this.renderForm(sectionInnerHTML);
            } else {
              console.error(
                "Error: .recipient-form class not found in the parsed HTML."
              );
              this.renderError();
            }
          })
          .catch((error) => {
            console.error("Error fetching the gift card form:", error);
            this.renderError();
          });
      }

       onClickFetchForm() {
        const variantId = this.dataset.variantId; // Get the variant ID dynamically
        if (variantId) {
          this.fetchForm(variantId);
        } else {
          console.error("Variant ID is missing!");
        }
      }

      renderForm(sectionInnerHTML) {
        if (!sectionInnerHTML) {
          this.innerHTML = "";
          return;
        }

        this.querySelector(".fetch-gift-form").style.display = "none";
        this.innerHTML = sectionInnerHTML.outerHTML;        
        const productForm = document.querySelector("gift-card-recipient-form");
        if (productForm) {
          productForm.prepend(this.clearButton); // Append the clear button to shopify-product-form
          this.clearButton.style.display = "inline-block"; // Show the clear button
        } else {
          console.error("Error: shopify-product-form not found.");
        }
      }

      clearForm() {
        this.innerHTML = "";
        const fetchButtonHtml =
          `
        <div class="fetch-gift-form receipient__form d-flex align-items-center gap-2 collapsed w-50 mb-3">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="1" y="1" width="16" height="16" rx="8" stroke="black" stroke-width="2"/>
          </svg>          
          <p class="m-0">` +
          wdtTheme.strings.recipient_check +
          `</p>
        </div>
      `;

        this.insertAdjacentHTML("beforeend", fetchButtonHtml);
        const newFetchButton = this.querySelector(".fetch-gift-form");
        if (newFetchButton) {
          newFetchButton.addEventListener(
            "click",
            this.onClickFetchForm.bind(this)
          );
        }

        this.clearButton.style.display = "none";
      }

      renderError() {
        this.innerHTML =
          "<p>There was an error loading the gift card form. Please try again.</p>";
      }
    }
  );
}

if (!customElements.get('shop-look-section')) {
  customElements.define('shop-look-section', class ShopLookSection extends HTMLElement {
    constructor() {
      super();
      this.swipers = [];
    }

    connectedCallback() {
      this.initializeShopLook();
      this.setupHotspotAccessibility();      
    }

    initializeShopLook() {
      this.initSwipers();
      this.attachHotspotClickEvents();     
      this.setupBuyAllTogetherButton();
    }

    initSwipers() {
      const swiperContainers = this.querySelectorAll("[data-shop-look-slider]");
      swiperContainers.forEach((slider) => {
        const sliderOptionsData = slider.getAttribute("data-shop-look-options");
        if (!sliderOptionsData) return;
        const defaultOptions = {
          effect: "slide",
          direction: "horizontal",
          autoplay: true,
          autoplaySpeed: 5,
          spaceBetweenSlides: 0,
          additionalOptions: {},
        };
        const sliderOptions = Object.assign({}, defaultOptions, JSON.parse(sliderOptionsData));

        const numericPattern = /^\d+$/;
        Object.keys(sliderOptions).forEach((key) => {
          if (typeof sliderOptions[key] === "string" && numericPattern.test(sliderOptions[key])) {
            sliderOptions[key] = parseInt(sliderOptions[key], 10);
          }
        });

        let autoplaySettings = false;
        if (sliderOptions.auto_play > 0) {
          autoplaySettings = { delay: 1000 * sliderOptions.auto_play };
        }

        let loopEnabled = sliderOptions.loop === "true" || sliderOptions.loop === true || sliderOptions.loop === 1;
        let centeredSlides = sliderOptions.centeredMode === "true" || sliderOptions.centeredMode === true;

        const swiperOptions = Object.assign({
          init: false,
          spaceBetween: sliderOptions.space,
          loop: loopEnabled,
          // preventClicks: true,
          // preventClicksPropagation: true,
          autoplay: autoplaySettings,
          centeredSlides: centeredSlides,
          speed: 2000,
          navigation: {
            nextEl: this.querySelector(".swiper-button-next"),
            prevEl: this.querySelector(".swiper-button-prev"),
          },
          pagination: {
            el: this.querySelector(".swiper-pagination"),
            clickable: true,
          },
          lazyLoading: true,
          focusableElements: "input, select, option, textarea, video, label",
          breakpoints: {
            320: { slidesPerView: sliderOptions.mobile, slidesPerColumn: 1 },
            576: { slidesPerView: sliderOptions.tablet, slidesPerColumn: 1 },
            992: { slidesPerView: sliderOptions.laptop, slidesPerColumn: 1 },
            1200: { slidesPerView: sliderOptions.desktop, slidesPerColumn: 1 },
          },
        }, sliderOptions.additionalOptions);

        const swiperInstance = new Swiper(slider, swiperOptions);

        swiperInstance.on("init", () => swiperInstance.update());
        swiperInstance.init();

        this.swipers.push(swiperInstance);
      });
    }

    attachHotspotClickEvents() {
      const hotspots = this.querySelectorAll(".section-shop-the-look .spots");
      hotspots.forEach((spot) => {
        spot.addEventListener("click", (e) => {
          const swiperId = e.target.getAttribute("data-id");
          if (swiperId) {
            const swiperContainer = e.target.closest(".shop-the-look").querySelector("[data-shop-look-slider]");
            const swiperInstance = this.swipers.find((swiper) => swiper.el === swiperContainer);

            if (swiperInstance) {
              const slides = Array.from(swiperContainer.querySelectorAll(".swiper-slide"));
              const targetSlide = slides.find((slide) => slide.getAttribute("data-id") === swiperId);

              if (targetSlide) {
                slides.forEach((slide) => slide.classList.remove("spot-clicked"));
                targetSlide.classList.add("spot-clicked");
                const slideIndex = slides.indexOf(targetSlide);
                swiperInstance.slideTo(slideIndex);
              }
            }
          }
        });
      });
    }

    setupBuyAllTogetherButton() {
      const buyAllTogetherButton = this.querySelector("#buyAllTogether");
      if (buyAllTogetherButton) {
        buyAllTogetherButton.addEventListener("click", () => {
          const bundleItems = Array.from(this.querySelectorAll(".variant-select")).map((select) => ({
            id: select.value,
            quantity: 1,
          }));

          fetch("/cart/add.js", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ items: bundleItems }),
          })
            .then((response) => response.json())
            .then(() => {
              showCartDrawer();
              fetchCart();
            })
            .catch((error) => console.error("Error adding bundle to cart:", error));
        });
      }
    }

    setupHotspotAccessibility() {
      const hotspots = this.querySelectorAll(".spots");
      if (hotspots.length > 0) {
        const firstActive = this.querySelector(".spots.active");
        if (!firstActive) {
          hotspots[0].classList.add("active");
        }
      }

      hotspots.forEach((hotspot) => {
        hotspot.addEventListener("click", function () {
          hotspots.forEach((spot) => spot.classList.remove("active"));
          this.classList.add("active");
        });

        hotspot.addEventListener("keydown", function (event) {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            this.click();
          }
        });
      });
    }
  });
}

document.addEventListener("DOMContentLoaded", function () {
  const shopLookSections = document.querySelectorAll("shop-look-section");
  shopLookSections.forEach((section) => {
    if (typeof section.connectedCallback === "function") {
      section.connectedCallback();
    }
  });
});



if (!customElements.get('wdt-collection-gallery')) {
  customElements.define('wdt-collection-gallery', class WDT_collectionGallery extends HTMLElement {
  constructor() {
    super();
    this.sliderConfigElement = this.querySelector("[data-slider-options]");
    this.bottomTextElements = document.querySelectorAll(".bottom-text");
    if (this.sliderConfigElement) this.initializeSlider();
  }

  initializeSlider() {
    const sliderOptionsData = this.sliderConfigElement.getAttribute("data-slider-options");
    if (!sliderOptionsData) return;

    const sliderOptions = $.extend(
      true,
      {
        additionalOptions: {},
      },
      JSON.parse(sliderOptionsData)
    );

    const numericPattern = /^\d+$/;
    Object.keys(sliderOptions).forEach((key) => {
      if (typeof sliderOptions[key] === "string" && numericPattern.test(sliderOptions[key])) {
        sliderOptions[key] = parseInt(sliderOptions[key], 10);
      }
    });

    const autoplaySettings = sliderOptions.auto_play > 0 ? { delay: 1000 * sliderOptions.auto_play } : false;
    const loopEnabled = sliderOptions.loop === "true" || sliderOptions.loop === true || sliderOptions.loop === 1;
    const centeredSlides = sliderOptions.mode === "true" || sliderOptions.mode === true;

    // Default Swiper options
    const swiperOptions = $.extend(true, {
      init: false,
      speed: 2000,
      spaceBetween: sliderOptions.space,
      loop: loopEnabled,
      preventClicks: true,
      preventClicksPropagation: true,
      autoplay: autoplaySettings,
      centeredSlides: centeredSlides,
      slideToClickedSlide: true,
      effect: "creative",
      grabCursor: true,
      slidesPerView: 3, // Default number of slides shown
      creativeEffect: {
        perspective: true,
        prev: {
          translate: ["-100%", -100, -300],
          rotate: [0, 0, 8],
          zIndex: 999,
          scale: 0.8,
        },
        next: {
          translate: ["100%", -60, -260],
          rotate: [0, 0, -8],
          zIndex: 999,
          scale: 0.8,
        },
        active: {
          translate: [0, 0, -300],
          rotate: [0, 0, -2],
          zIndex: -1,
          scale: 1.2,
        },
      },
      navigation: {
        nextEl: this.sliderConfigElement.querySelector(".swiper-button-next"),
        prevEl: this.sliderConfigElement.querySelector(".swiper-button-prev"),
      },
      pagination: {
        el: this.sliderConfigElement.querySelector(".swiper-pagination"),
        clickable: true,
      },
      lazyLoading: true,
      focusableElements: "input, select, option, textarea, video, label",

      // Responsive breakpoints
      breakpoints: {
     1199: {
          slidesPerView: 3,
          spaceBetween: 10,
          creativeEffect: {
            prev: {
              translate: ["-82%", -50, 5],
              rotate: [0, 0, 8],
              zIndex: 999,
              scale: 0.7,
            },
            next: {
              translate: ["82%", -50, 5],
              rotate: [0, 0, -8],
              zIndex: 999,
              scale: 0.7,
            },
            active: {
              translate: [0, 0, -300],
              rotate: [0, 0, -2],
              zIndex: -1,
              scale: 1.2,
            },
          },
        },
        786: {
          slidesPerView: 3,
          spaceBetween: 10,
          creativeEffect: {
            prev: {
              translate: ["-85%", -15, 5],
              rotate: [0, 0, 8],
              zIndex: 999,
              scale: 0.8,
            },
            next: {
              translate: ["85%", -15, 5],
              rotate: [0, 0, -8],
              zIndex: 999,
              scale: 0.8,
            },
            active: {
              translate: [0, 0, -300],
              rotate: [0, 0, -2],
              zIndex: -1,
              scale: 1.2,
            },
          },
        },
        576: {
          slidesPerView:2,
          spaceBetween: 10,          
          creativeEffect: {
            prev: {
              translate: ["-78%", -35, 5],
              rotate: [0, 0, 8],
              zIndex: 999,
              scale: 0.6,
            },
            next: {
              translate: ["79%", -20, 10],
              rotate: [0, 0, -6],
              zIndex: 999,
              scale: 0.6,
            },
            active: {
              translate: [0, 0, -300],
              rotate: [0, 0, -2],
              zIndex: -1,
              scale: 1.2,
            },
          },
        },
       320: {
          slidesPerView: 1,
          spaceBetween: 10,       
        },
       
     
      },
    }, sliderOptions.additionalOptions);

    // Initialize Swiper instance
    const swiperContainer = this.sliderConfigElement.querySelector("[data-swiper-slider]");
    this.swiperInstance = new Swiper(swiperContainer, swiperOptions);

    // Listen for breakpoint changes to adjust `creativeEffect`
    this.swiperInstance.on("resize", () => {
      this.adjustTransformForCurrentBreakpoint();
    });

    this.swiperInstance.on("slideChange", () => {
      this.handleSlideChange(this.swiperInstance);
    });

    this.swiperInstance.on("init", () => {
      this.swiperInstance.update();
    });

    this.swiperInstance.init();
  }

  handleSlideChange(swiperInstance) {
    const activeSlide = swiperInstance.slides[swiperInstance.activeIndex];
    const matchingId = activeSlide.getAttribute("data-gallery-matching-id");

    if (matchingId) {
      this.bottomTextElements.forEach((element) => {
        if (element.getAttribute("data-gallery-matching-id") === matchingId) {
          element.classList.add("show");
          element.classList.remove("hidden");
        } else {
          element.classList.remove("show");
          element.classList.add("hidden");
        }
      });
    }
  }

  // Method to adjust active slide transforms based on breakpoints
  adjustTransformForCurrentBreakpoint() {
    const swiper = this.swiperInstance;
    if (!swiper) return;

    // Get the current breakpoint (based on the window width)
    const windowWidth = window.innerWidth;

    // Determine which breakpoint has been triggered and apply corresponding transform values
    if (windowWidth <= 320) {
      swiper.params.creativeEffect.active = {
        translate: [0, 0, -200],
        rotate: [0, 0, -2],
        scale: 1.5,
      };
    } else if (windowWidth <= 576) {
      swiper.params.creativeEffect.active = {
        translate: [0, 0, -200],
        rotate: [0, 0, -2],
        scale: 1.2,
      };
    } else if (windowWidth <= 990) {
      swiper.params.creativeEffect.active = {
        translate: [0, 0, -300],
        rotate: [0, 0, -2],
        scale: 1.2,
      };
    } else {
      swiper.params.creativeEffect.active = {
        translate: [0, 0, -300],
        rotate: [0, 0, -2],
        scale: 1.2,
      };
    }

    // Update Swiper with new settings without re-initializing
    swiper.update();
  }
});
}



function initQuickModal() {
  const quickViewButtons = document.querySelectorAll('.quick-view-btn'); 
  quickViewButtons.forEach(button => {
  button.addEventListener('click', function () {
    const productUrl = button.getAttribute('data-product-url');
    const quickViewContent = document.getElementById('quickViewContent'); // Offcanvas body content
    quickViewContent.innerHTML = 'Loading...';
    isQuickViewOpen = true;
    // Fetch product data
    fetch(productUrl)
      .then(response => response.text())
      .then(data => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(data, 'text/html');
        const productInfo = doc.querySelector('product-template');

        if (productInfo) {
          updateDOM(productInfo);
          quickViewContent.innerHTML = productInfo.innerHTML;

          // Initialize Bootstrap Offcanvas
          const quickViewOffcanvas = new bootstrap.Offcanvas(document.getElementById('quickViewOffcanvas'));
          quickViewOffcanvas.show();          
          document.getElementById('quickViewOffcanvas').addEventListener('hidden.bs.offcanvas', () => {                     
            quickViewOffcanvas.hide();           
            isQuickViewOpen = false;
          });          
                     
          initializeProductGalleryInModal(quickViewContent);
        } else {
          quickViewContent.innerHTML = 'Product information not found.';
        }
      })
      .catch(error => {
        quickViewContent.innerHTML = 'Sorry, an error occurred while loading the product.';
        console.error('Error fetching product data:', error);
      });
  });
});

  
}

function updateDOM(htmlDoc) {  
  const productRecommendations = htmlDoc.querySelector('product-recommendations');
  if (productRecommendations) productRecommendations.remove();
  const productPickup = htmlDoc.querySelector('product-availability-check');
  if (productPickup) productPickup.remove();
  const modelText = htmlDoc.querySelector('.block-popup');
  if (modelText) modelText.remove();
  const shortText = htmlDoc.querySelector('.product-text');
  if (shortText) shortText.remove();
}

function initializeProductGalleryInModal() {
  
  const thumbnailContainer = document.querySelector(".product-thumbnails");
  const mainGalleryContainer = document.querySelector(".product-media-gallery");

  if (!thumbnailContainer || !mainGalleryContainer) {
    console.warn("Product Gallery: Required containers not found in modal.");
    return;
  }
  const productGallery = new ProductGallery();
  document.querySelector("#quickModalCloseButton").addEventListener("click", () => {
    productGallery.destroySwipers(); 
  });
}


function initializeProductGalleryInModal(modalContent) {
   if (modalContent) {    
    new ProductGallery(modalContent);
    const variantSelectors = modalContent.querySelectorAll('variant-selector');    
    variantSelectors.forEach((variantSelectorEl) => {
      if (typeof variantSelectorEl.init === 'function') {
        variantSelectorEl.init(modalContent);
        //console.log("A"+modalContent.innerHTML);
      } else {
        const variantSelector = new VariantSelector(modalContent);
        if (typeof variantSelector.init === 'function') {
          variantSelector.init(modalContent);
        } else {
          console.warn("VariantSelector instance does not have an init method.");
        }
       // console.log("B");
      }
    });
  } else {
    console.error("Modal content not found for ProductGallery initialization.");
  }
}


function syncVariantToStickyBar(currentVariant) {
  const stickySelect = document.querySelector(".stickySelect"); 
  if (stickySelect) {
    const options = stickySelect.options;
    for (let i = 0; i < options.length; i++) {
      const option = options[i];
      if (option.value == currentVariant.id) {
        stickySelect.selectedIndex = i;
        stickySelect.dispatchEvent(new Event("change"));
       // console.log(`Sticky bar updated to variant ID: ${currentVariant.id}`);
        return;
      }
    }
    //console.warn(`No matching variant found for ID: ${currentVariant.id}`);
  } else {
   // console.error("Sticky select element not found in the DOM.");
  }
}



if (!customElements.get('quiz-section')) {
  customElements.define('quiz-section', class QuizSection extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    this.initQuiz();
  }

  initQuiz() {
    const totalQuestions = this.querySelectorAll('.quiz-question').length;
    const progressBar = this.querySelector('#quiz-progress-bar');
    const resultsButton = this.querySelector('#view-results-button');
    const resetButton = this.querySelector('#reset-quiz-button');
    const resultsContainer = this.querySelector('#results-container');
    const quizClose = this.querySelector('#quizClose');

    if (!resultsButton) {
      console.error('Results button not found in the quiz section.');
      return;
    }

    resultsButton.disabled = true;

    // Initialize Swiper
    const swiper = new Swiper(this.querySelector('.quizSlider'), {
      slidesPerView: 1,
      loop: false,
      spaceBetween: 50,
      autoHeight: true,
      draggable: false,
      allowTouchMove: false,
      effect: 'fade',
    fadeEffect: {
      crossFade: true
    },
       //speed: 2000,
      navigation: {
        nextEl: this.querySelector('.swiper-button-next'),
        prevEl: this.querySelector('.swiper-button-prev'),
      },
    });

    // Attach Swiper events
    swiper.on('init', () => this.updateNumericPagination(swiper));
    swiper.on('slideChange', () => this.updateNumericPagination(swiper));
    
    // Trigger initialization event
    swiper.init();

    // Disable Next button until an answer is selected
    this.querySelectorAll('.quiz-question').forEach((questionEl) => {
      const nextButton = this.querySelector('.swiper-button-next');
      const radioButtons = questionEl.querySelectorAll('.form-check-input');
      nextButton.disabled = true;
      radioButtons.forEach((radioButton) => {
        radioButton.addEventListener('change', () => {
          if (radioButton.checked) {
            nextButton.disabled = false;
            this.checkAllQuestionsAnswered(totalQuestions, resultsButton);
          }
        });
      });
    });

    resultsButton.addEventListener('click', () => {
      const selectedAnswers = [];
      this.querySelectorAll('.quiz-question').forEach((question) => {
        const questionId = question.dataset.questionIndex;
        const selectedOption = this.querySelector(`input[name="question_${questionId}"]:checked`);
        if (selectedOption) {
          selectedAnswers.push(selectedOption.value);
        }
      });

      if (selectedAnswers.length !== totalQuestions) {
        alert('Please answer all questions before viewing results.');
        return;
      }

      this.fetchProductsBasedOnTags(selectedAnswers, resultsContainer);
    });

    resetButton.addEventListener('click', () => {
      this.resetQuiz(swiper, resultsButton);
    });

    quizClose.addEventListener('click', () => {
      this.resetQuiz(swiper, resultsButton);
    });
  }

  updateNumericPagination(swiperInstance) {
    const swiperContainer = this.querySelector('.quizSlider');
    if (!swiperContainer) return;
    const currentIndex = swiperInstance.realIndex + 1;
    const totalSlides = swiperInstance.slides.length;

    swiperContainer.querySelector('.swiper-counter').innerHTML = 
      `<span class="count h1">0${currentIndex}</span>/<span class="total h2">0${totalSlides}</span>`;
  }

  checkAllQuestionsAnswered(totalQuestions, resultsButton) {
    const answeredQuestions = this.querySelectorAll('.quiz-question input[type="radio"]:checked').length;
    resultsButton.disabled = answeredQuestions !== totalQuestions;
  }

  fetchProductsBasedOnTags(tags, resultsContainer) {
    const query = tags.join(' ');
    const encodedQuery = encodeURIComponent(query);
    const url = `${window.routes.search_url}/?view=quiz&type=product&q=${encodedQuery}`;

    fetch(url)
      .then((response) => response.json())
      .then((products) => this.displayProducts(products, resultsContainer))
      .catch((error) => {
        resultsContainer.innerHTML = `<p>Error loading products: ${error.message}</p>`;
      });
  }

  displayProducts(products, resultsContainer) {
    if (products.length === 0) {
      resultsContainer.innerHTML = '<p class="h5">No products found based on your choices.</p>';
      return;
    }

    let resultsHTML = '<div class="row row-gap-4">';
    products.forEach((product) => {
      resultsHTML += `
        <div class="col-md-6">
          <div class="card mb-3">
           <div class="card-img"> <img src="${product.image}" class="card-img-top border rounded-4" alt="${product.title}"></div>
            <div class="card-body px-0">
              <h5 class="card-title"><a href="${product.url}">${product.title}</a></h5>
              <p class="price fw-bold">${product.price}</p>
              <a href="${product.url}" class="btn btn-primary">View</a>
            </div>
          </div>
        </div>`;
    });
    resultsHTML += '</div>';
    resultsContainer.innerHTML = resultsHTML;
  }

  resetQuiz(swiper, resultsButton) {
    this.querySelectorAll('input[type="radio"]:checked').forEach((radio) => {
      radio.checked = false;
    });
    swiper.slideTo(0);
    resultsButton.disabled = true;
  }
});
}

if (!customElements.get('content-showcase')) {
  customElements.define('content-showcase', class ContentShowcase extends HTMLElement {
  constructor() {
    super();
    this.processTitleBlock = this.processTitleBlock.bind(this);
  }

  connectedCallback() {
    this.processTitleBlock();
  }

  processTitleBlock() {
    const titleBlock = this.querySelector(".title_block");
    if (!titleBlock) return;

    const spans = Array.from(titleBlock.querySelectorAll("span.text-word"));
    const images = Array.from(titleBlock.querySelectorAll("img"));
    let combinedText = "";
    let newSpan = null;

    spans.forEach((span, index) => {
      const nextSibling = span.nextElementSibling;

      // Start a new span if `newSpan` is null
      if (!newSpan) {
        newSpan = document.createElement("span");
        newSpan.className = "text-word align-middle";
        titleBlock.insertBefore(newSpan, span);
      }
      combinedText += span.textContent + " ";
      span.remove();
      if (!nextSibling || !nextSibling.classList.contains("text-word")) {
        newSpan.textContent = combinedText.trim();
        combinedText = "";
        newSpan = null; 
      }
    });

    
    images.forEach((img, index) => {
      const altText = spans[index]?.textContent || `Image ${index + 1}`;
      img.setAttribute("alt", altText.trim());
    });
  }
});
}

document.addEventListener('DOMContentLoaded', () => { 
  const options = document.querySelectorAll('.form-check-label');
  options.forEach(option => {    
    option.setAttribute('tabindex', '0');
    option.addEventListener('keydown', (event) => {
      const inputElement = option.previousElementSibling; 
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault(); 
        inputElement.checked = true; 
        inputElement.dispatchEvent(new Event('change'));
      }
    });
    option.addEventListener('focus', () => {
      option.classList.add('focused');
    });
    option.addEventListener('blur', () => {
      option.classList.remove('focused');
    });
  });
});

document.addEventListener('DOMContentLoaded', function() {
  cardSwatch();
  initQuickModal();
  if (document.querySelector(".tab-style-default")) {
    initializeTabs();
  }
});


  AOS.init({
    startEvent: 'DOMContentLoaded',
    once: true,
    offset: 50, 
    delay: 0, 
    duration: 1000    
  });
  window.addEventListener('load', function() {
    AOS.refresh();
    if (document.querySelector(".tab-style-default")) {
    initializeTabs();
  }
  });

function makeTimer() {
    $('.product-deal-count').each(function() {
        var endTime = new Date($(this).attr('data-end-time'));		
        endTime = (Date.parse(endTime) / 1000);
        var now = new Date();
        now = (Date.parse(now) / 1000);
        var timeLeft = endTime - now;
        
        if(timeLeft > 0) {         
            var days = Math.floor(timeLeft / 86400); 
            var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
            var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600 )) / 60);
            var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

            if (hours < 10) { hours = "0" + hours; }
            if (minutes < 10) { minutes = "0" + minutes; }
            if (seconds < 10) { seconds = "0" + seconds; }

            $(this).find(".days").html(days < 10 ? "0" + days : days);
            $(this).find(".hours").html(hours);
            $(this).find(".minutes").html(minutes);
            $(this).find(".seconds").html(seconds);

        } else {
            $(this).find(".days").html("00");
            $(this).find(".hours").html("00");
            $(this).find(".minutes").html("00");
            $(this).find(".seconds").html("00");

            $(this).find(".deal-label").hide();  
            $(this).find(".deal-clock").hide();        
        }
    });
}

$(document).ready(function() {
    makeTimer();
    setInterval(function() { makeTimer(); }, 1000);
});


function initializeTabs() {
  const box = document.querySelector(".tab-style-default");
  if (!box) return; 

  const scrItems = document.querySelectorAll(".tab__item");
  if (scrItems.length === 0) return;

  let scrIWidth = 0;
 
  scrItems.forEach((item) => {
    scrIWidth += item.offsetWidth; 
  });

  
  const productTabMenu = document.querySelector(".tab_menu");
  if (!productTabMenu) return;
  productTabMenu.style.width = `${scrIWidth}px`;

 
  scrItems.forEach((item) => {
    item.addEventListener("click", () => {
      scrItems.forEach((i) => i.classList.remove("on")); // Remove "on" class from all items
      item.classList.add("on"); 
      muCenter(item); 
    });
  });

  function muCenter(target) {
    const boxItems = box.querySelectorAll(".tab__item");
    const boxHalf = box.offsetWidth / 2; // Half of the box width
    let listWidth = 0;
    let targetLeft = 0;

 
    boxItems.forEach((item) => {
      listWidth += item.offsetWidth;
    });
  
    for (let i = 0; i < [...boxItems].indexOf(target); i++) {
      targetLeft += boxItems[i].offsetWidth;
    }

    const selectTargetPos = targetLeft + target.offsetWidth / 2;

    let pos;
    if (selectTargetPos <= boxHalf) {    
      pos = 0;
    } else if (listWidth - selectTargetPos <= boxHalf) {   
      pos = listWidth - box.offsetWidth;
    } else {     
      pos = selectTargetPos - boxHalf;
    }
    setTimeout(() => {
      box.scrollTo({
        left: pos,
        behavior: "smooth",
      });
    }, 200);
  }
}

// Variant accessibility 
document.querySelectorAll('.variant-options .variant-option-item').forEach((item) => {
  item.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      item.click();
    }
  });

  item.addEventListener('click', () => {
    const options = item.parentNode.querySelectorAll('.variant-option-item');
    options.forEach((opt) => opt.setAttribute('aria-selected', 'false'));
    item.setAttribute('aria-selected', 'true');
  });
});
