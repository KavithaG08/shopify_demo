class PredictiveSearch extends HTMLElement {
  constructor() {
    super();

    this.input = this.querySelector('input[type="search"]');
    this.predictiveSearchResults = this.querySelector('[data-predictive-search]');
    this.searchModal = this.closest('#searchBox'); 
    this.input.addEventListener('input', this.debounce(this.onInputChange.bind(this), 300)); 
    document.addEventListener('click', (e) => this.handleOutsideClick(e));
  }

 
  async onInputChange() {
    const searchTerm = this.input.value.trim();        
    if (!searchTerm.length) {
      this.close();
      return;
    }
    await this.getSearchResults(searchTerm); 
  }

  async getSearchResults(searchTerm) {
    try {
      const response = await fetch(`/search/suggest?q=${searchTerm}&section_id=predictive-search`);
      if (!response.ok) {
        this.close();
        throw new Error(response.status);        
      }

      // Parse the HTML response from the server
      const text = await response.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(text, 'text/html');
      const resultsMarkup = doc.querySelector('#predictive-search-results-groups-wrapper').innerHTML;

      this.predictiveSearchResults.innerHTML = resultsMarkup;    
        if (resultsMarkup.includes('No results found')) {
        this.searchModal.classList.remove('open');
      } else {
        this.searchModal.classList.add('open');
        this.open();
      }      
    } catch (error) {
      this.close();
      console.error('Error fetching search results:', error);
    }
  }
  open() {
    if (this.searchModal) {
      this.searchModal.classList.add('open'); 
    }
    this.predictiveSearchResults.style.display = 'block'; 
    this.input.setAttribute('aria-expanded', 'true');     
  }
 
  close() {
    if (this.searchModal) {
      this.searchModal.classList.remove('open'); 
    }
    this.predictiveSearchResults.style.display = 'none'; 
    this.input.setAttribute('aria-expanded', 'false');      
  }
  debounce(fn, wait) {
    let timeout;
    return (...args) => {
        this.input.classList.add("loading");
        clearTimeout(timeout);
        timeout = setTimeout(() => {
        this.input.classList.remove("loading");            
            fn.apply(this, args);
        }, wait);
    };
}


  handleOutsideClick(event) {  
    if (!this.contains(event.target) && this.searchModal.classList.contains('open')) {
      this.close(); 
    }
  }
}

customElements.define('predictive-search', PredictiveSearch);
